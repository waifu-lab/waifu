# 角色與記憶系統架構

---

## 目錄結構

```
~/.waifu/
├── characters/
│   └── {character_name}/
│       ├── soul.md           ← 角色靈魂（靜態設定）
│       ├── avatar.{ext}      ← 頭像（png / jpg / webp）
│       └── live2d/           ← Live2D 模型資料夾
│
└── memory/                   ← 檔案記憶系統（動態累積）
    ├── {character_name}/
    │   ├── direct/
    │   │   └── {source}:{user_id}.md     ← DM 歷史 + 關係層
    │   └── groups/
    │       └── {source}:{room_id}.md     ← 群組共用歷史
    └── _sessions/            ← 暫時性，不綁角色
        └── ws:{token}.md
```

---

## soul.md 格式

角色的靜態設定，餵入 `system_prompt`。

```markdown
# 角色卡: Sakura

## 身份
- 名字: Sakura
- 自稱: わたし（中文時用「我」）
- 年齡設定: 永遠17歲
- 口癖: 句尾常加「呢～」

## 個性
溫柔、有點傲嬌、對在乎的人容易不好意思。
對陌生人有禮但帶一點距離感。

## 喜惡
- 喜歡: 貓咪、雨天、讀推理小說
- 討厭: 被催促、不誠實

## 說話風格
親密度低 → 敬語、保持距離
親密度高 → 撒嬌、使用暱稱、偶爾吃醋

## 關係等級行為
- Lv0 陌生人: 你好，請問有什麼事嗎？
- Lv1 熟人: 啊，又是你。（小傲嬌）
- Lv2 朋友: 今天過得怎樣？（主動關心）
- Lv3 親密: 笨蛋，才不是這樣呢～
```

---

## 記憶檔案格式（memory/）

關係層與對話歷史**合在同一個 md 檔**。

```markdown
# Memory: Alice (discord:user:123456)

## 關係
- 親密度: 2
- Sakura 叫她: Alice醬
- 初次見面: 2026-04-10

## 記住的事
- 討厭香菜
- 資工系大三，快期末考了
- 有一隻橘貓叫「橘子」

---

## 近期對話（最近 20 則）

[verbatim messages]

## 舊對話摘要

Alice 在四月初問過關於 Python 非同步的問題，Sakura 解釋了 asyncio 的基本用法。
```

---

## 記憶策略：雙層記憶

| 層 | 內容 | 保留規則 |
|---|---|---|
| **近期原文** | 最近 N 則對話逐字記錄 | 滑動視窗，超過上限時壓入摘要層 |
| **舊對話摘要** | LLM 自動摘要舊訊息 | 累積式，可多次追加 |

MVP 先實作雙層記憶，之後可無痛升級為語義檢索（接 hai 的 vector store）。

---

## ContextBuilder 組裝邏輯

```
system_prompt
  = soul.md（角色靜態設定）
  + 當前發話者的關係層（memory/direct/{user_id}.md 的「關係」區塊）

messages
  = 群組共用歷史（GROUP）or 個人歷史（DIRECT / SESSION）
  + 近期原文 + 舊對話摘要
```

GROUP 模式：waifu 帶著整個房間的歷史，但對每個發話者額外注入他的關係層。

---

## 對話模式與記憶範圍對應

| 模式 | 記憶檔案 | 關係層 |
|---|---|---|
| SESSION | `_sessions/ws:{token}.md` | 無（暫時性） |
| DIRECT | `direct/{source}:{user_id}.md` | 同檔案內 |
| GROUP | `groups/{source}:{room_id}.md`（共用） + `direct/{source}:{user_id}.md`（關係） | 從個人檔案讀取 |
