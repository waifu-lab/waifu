# HistoryTree API 文件


啟動後可用 URL：
- `http://localhost:8000`
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## 2. API 總覽

| 方法 | 路徑                              | 用途                         |
| ---- | --------------------------------- | ---------------------------- |
| GET  | `/`                               | 服務基本狀態                 |
| GET  | `/health`                         | 健康檢查（Qdrant/Neo4j）     |
| POST | `/documents`                      | 以檔案路徑攝取文件           |
| POST | `/documents/upload`               | 上傳檔案並攝取               |
| POST | `/query`                          | 問答檢索（語意 + BM25 + 圖） |
| GET  | `/entities`                       | 依名稱搜尋實體               |
| GET  | `/entities/{entity_id}`           | 取得單一實體                 |
| GET  | `/entities/{entity_id}/relations` | 查實體關係                   |
| GET  | `/facts`                          | 依條件查事實                 |
| GET  | `/facts/conflicts`                | 查衝突事實                   |
| GET  | `/facts/{fact_id}`                | 取得單一事實                 |

## 3. 呼叫範例

以下範例預設 base URL 為：

```bash
BASE_URL="http://localhost:8000"
```

### 3.1 根路由

```bash
curl "$BASE_URL/"
```

範例回應：

```json
{
  "status": "ok",
  "message": "HistoryTree API is running"
}
```

### 3.2 健康檢查

```bash
curl "$BASE_URL/health"
```

範例回應（healthy）：

```json
{
  "status": "healthy",
  "vector_store": {
    "collection": "historytree",
    "points": 123
  },
  "graph_store": "connected"
}
```

### 3.3 以檔案路徑攝取文件

```bash
curl -X POST "$BASE_URL/documents" \
  -H "Content-Type: application/json" \
  -d '{
    "file_path": "localtest/example.txt"
  }'
```

範例回應：

```json
{
  "status": "success",
  "message": "Document ingested successfully",
  "statistics": {
    "document_count": 1,
    "chunk_count": 4,
    "fact_count": 12,
    "entity_count": 9,
    "facts_added": 10
  }
}
```

### 3.4 上傳檔案並攝取

```bash
curl -X POST "$BASE_URL/documents/upload" \
  -F "file=@localtest/example.txt"
```

### 3.5 查詢（/query）

```bash
curl -X POST "$BASE_URL/query" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "小明在哪裡工作？",
    "top_k": 5,
    "rerank": true
  }'
```

時間點查詢：

```bash
curl -X POST "$BASE_URL/query" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "2024 年小明在哪裡工作？",
    "top_k": 5,
    "at_time": "2024-12-31T23:59:59",
    "rerank": false
  }'
```

範例回應（節錄）：

```json
{
  "query": "小明在哪裡工作？",
  "at_time": null,
  "intent": "fact",
  "facts": [],
  "chunks": [],
  "entities": [],
  "fact_count": 0,
  "chunk_count": 0
}
```

### 3.6 搜尋實體

```bash
curl "$BASE_URL/entities?name=小明&entity_type=Person&limit=20"
```

### 3.7 取得實體

```bash
curl "$BASE_URL/entities/<entity_id>"
```

### 3.8 取得實體關係

```bash
curl "$BASE_URL/entities/<entity_id>/relations?status=ACTIVE&limit=20"
```

### 3.9 條件查事實

```bash
curl "$BASE_URL/facts?subject=小明&predicate=works_at&status=ACTIVE&limit=20"
```

指定時間點：

```bash
curl "$BASE_URL/facts?subject=小明&predicate=works_at&at_time=2024-12-31T23:59:59"
```

### 3.10 查衝突事實

```bash
curl "$BASE_URL/facts/conflicts?subject=小明&predicate=works_at"
```

### 3.11 取得單一事實

```bash
curl "$BASE_URL/facts/<fact_id>"
```

## 4. Python 呼叫範例（httpx）

```python
import httpx

BASE_URL = "http://localhost:8000"

# 1) 攝取文件
resp = httpx.post(
    f"{BASE_URL}/documents",
    json={"file_path": "localtest/example.txt"},
    timeout=120,
)
resp.raise_for_status()
print("ingest:", resp.json())

# 2) 查詢
resp = httpx.post(
    f"{BASE_URL}/query",
    json={"query": "小明在哪裡工作？", "top_k": 5, "rerank": True},
    timeout=120,
)
resp.raise_for_status()
print("query:", resp.json())

# 3) 搜尋實體
resp = httpx.get(
    f"{BASE_URL}/entities",
    params={"name": "小明", "entity_type": "Person", "limit": 10},
    timeout=30,
)
resp.raise_for_status()
print("entities:", resp.json())
```

## 5. 常見錯誤與排查

### 500: `HistoryTree not initialized`

可能原因：
- `OPENAI_API_KEY` 沒設定
- Neo4j 或 Qdrant 無法連線

建議：
1. 確認環境變數完整
2. 確認 Neo4j 在 `7687`、Qdrant 在 `6333`
3. 先呼叫 `/health` 看詳細狀態

### 404: `File not found`

`POST /documents` 的 `file_path` 是 API 服務所在機器可讀路徑，請確認：
- 路徑存在
- API 執行帳號有讀取權限

## 6. 資料模型重點

### IngestRequest

文件攝取請求模型。

| 欄位        | 型態             | 必填 | 描述                                             |
| ----------- | ---------------- | ---- | ------------------------------------------------ |
| `file_path` | `string`         | 是   | 文件路徑（API 服務所在機器可讀的相對或絕對路徑） |
| `namespace` | `string \| null` | 否   | 命名空間（目前在實作中尚未使用）                 |

**範例：**

```json
{
  "file_path": "localtest/example.txt",
  "namespace": null
}
```

### IngestResponse

文件攝取回應模型，包含攝取統計資訊。

| 欄位         | 型態     | 描述                                                                          |
| ------------ | -------- | ----------------------------------------------------------------------------- |
| `status`     | `string` | 狀態，通常為 `"success"`                                                      |
| `message`    | `string` | 說明訊息                                                                      |
| `statistics` | `dict`   | 攝取統計，含 `document_count`、`chunk_count`、`fact_count`、`entity_count` 等 |

**範例：**

```json
{
  "status": "success",
  "message": "Document ingested successfully",
  "statistics": {
    "document_count": 1,
    "chunk_count": 4,
    "fact_count": 12,
    "entity_count": 9,
    "facts_added": 10
  }
}
```

### SearchRequest

查詢請求模型。

| 欄位      | 型態             | 預設值 | 必填 | 描述                              |
| --------- | ---------------- | ------ | ---- | --------------------------------- |
| `query`   | `string`         | -      | 是   | 查詢文本，支援自然語言            |
| `top_k`   | `int`            | 5      | 否   | 返回的結果數量上限                |
| `at_time` | `string \| null` | null   | 否   | ISO-8601 時間戳記，用於時間點查詢 |
| `rerank`  | `bool`           | false  | 否   | 是否透過 LLM 重新排序結果         |

**範例：**

```json
{
  "query": "小明在哪裡工作？",
  "top_k": 5,
  "at_time": null,
  "rerank": true
}
```

### SearchResponse

查詢回應模型，含多層次檢索結果。

| 欄位          | 型態             | 描述                                      |
| ------------- | ---------------- | ----------------------------------------- |
| `query`       | `string`         | 原始查詢文本                              |
| `at_time`     | `string \| null` | 查詢時間點（若有指定）                    |
| `intent`      | `string \| null` | 推測的查詢意圖，如 `"fact"` 或 `"entity"` |
| `facts`       | `array`          | 符合的事實列表                            |
| `chunks`      | `array`          | 符合的文本片段列表                        |
| `entities`    | `array`          | 符合的實體列表                            |
| `fact_count`  | `int`            | 返回的事實數量                            |
| `chunk_count` | `int`            | 返回的文本片段數量                        |

**範例：**

```json
{
  "query": "小明在哪裡工作？",
  "at_time": null,
  "intent": "fact",
  "facts": [
    {
      "subject": "小明",
      "predicate": "works_at",
      "object": "科技公司",
      "status": "ACTIVE"
    }
  ],
  "chunks": [
    {
      "text": "小明在科技公司工作...",
      "source": "localtest/example.txt"
    }
  ],
  "entities": [
    {
      "id": "person_xiaoming",
      "name": "小明",
      "type": "Person"
    }
  ],
  "fact_count": 1,
  "chunk_count": 1
}
```

### FactArchiveResponse

事實檔案/存檔回應模型。

| 欄位      | 型態     | 描述                               |
| --------- | -------- | ---------------------------------- |
| `status`  | `string` | 狀態，如 `"success"` 或 `"failed"` |
| `fact_id` | `string` | 被檔案化/存檔的事實 ID             |

**範例：**

```json
{
  "status": "success",
  "fact_id": "fact_12345"
}
```

### Entity 模型

| 欄位          | 型態             | 描述                                                       |
| ------------- | ---------------- | ---------------------------------------------------------- |
| `id`          | `string`         | 實體唯一識別符                                             |
| `name`        | `string`         | 實體名稱                                                   |
| `type`        | `string`         | 實體類型，如 `"Person"`、`"Organization"`、`"Location"` 等 |
| `description` | `string \| null` | 實體描述（若有）                                           |

### Fact 模型

| 欄位         | 型態             | 描述                                                     |
| ------------ | ---------------- | -------------------------------------------------------- |
| `id`         | `string`         | 事實唯一識別符                                           |
| `subject`    | `string`         | 主體（通常為實體名稱或 ID）                              |
| `predicate`  | `string`         | 述詞（關係類型），如 `"works_at"`、`"located_in"` 等     |
| `object`     | `string`         | 賓體（通常為實體名稱或 ID）                              |
| `status`     | `string`         | 事實狀態，如 `"ACTIVE"`、`"CONFLICTED"`、`"ARCHIVED"` 等 |
| `valid_from` | `string \| null` | 事實有效起始時間（ISO-8601）                             |
| `valid_to`   | `string \| null` | 事實有效結束時間（ISO-8601）                             |
| `source`     | `string \| null` | 事實來源文件或引用                                       |
