# Plugin 系統與資料庫 Models 架構

---

## 目錄

- [Plugin 系統與資料庫 Models 架構](#plugin-系統與資料庫-models-架構)
  - [目錄](#目錄)
  - [1. Plugin 系統現況與缺口](#1-plugin-系統現況與缺口)
    - [現有架構（已完成）](#現有架構已完成)
    - [已知缺口](#已知缺口)
  - [2. PluginRegistry 修正](#2-pluginregistry-修正)
  - [3. Plugin 資料夾與 importlib 載入](#3-plugin-資料夾與-importlib-載入)
    - [目錄位置](#目錄位置)
    - [metadata.json 格式](#metadatajson-格式)
    - [PluginLoader](#pluginloader)
  - [4. 資料庫 Models](#4-資料庫-models)
    - [PluginConfig](#pluginconfig)
    - [MCPServer](#mcpserver)
    - [AppConfig](#appconfig)
    - [Character](#character)
    - [Relationship](#relationship)
  - [5. Service 層（DB + Runtime 雙寫）](#5-service-層db--runtime-雙寫)
    - [PluginService](#pluginservice)
    - [MCPService](#mcpservice)
    - [AppConfigService](#appconfigservice)
  - [6. API 端點設計](#6-api-端點設計)
    - [Plugin API](#plugin-api)
    - [MCP API](#mcp-api)
    - [Config API](#config-api)
    - [Character API](#character-api)
  - [7. AppConfig 熱更新](#7-appconfig-熱更新)
  - [8. 角色與記憶 Models](#8-角色與記憶-models)
  - [9. 啟動時初始化流程](#9-啟動時初始化流程)
  - [10. 完整目錄結構（新增部分）](#10-完整目錄結構新增部分)

---

## 1. Plugin 系統現況與缺口

### 現有架構（已完成）

```
PluginManager          load / unload / enable / disable / list
PluginRegistry         _tools / _hooks / _mcp_adapters（唯讀存取）
router/plugin.py       GET / POST enable / POST disable / DELETE
```

### 已知缺口

| 問題                               | 位置                 | 影響                                                              |
| ---------------------------------- | -------------------- | ----------------------------------------------------------------- |
| `PluginRegistry` 無 `remove_*`     | `plugin/__init__.py` | `unload()` 只從字典移除 plugin，tools/hooks/mcp 仍殘留在 registry |
| Plugin router 無安裝端點           | `router/plugin.py`   | 無法透過 API 載入新 plugin                                        |
| `ContextBuilder` config 不可熱更新 | `agent/context.py`   | 改 model/system_prompt 需重啟                                     |
| Plugin 無 DB 持久化                | —                    | 重啟後所有 plugin 設定消失                                        |

---

## 2. PluginRegistry 修正

在 `waifu/plugin/__init__.py` 的 `PluginRegistry` 加入 remove 系列方法：

```python
class PluginRegistry:
    def remove_tool(self, name: str) -> None:
        self._tools = [t for t in self._tools if t.name != name]

    def remove_hook(self, name: str) -> None:
        self._hooks = [h for h in self._hooks if h.name != name]

    def remove_mcp(self, name: str) -> None:
        self._mcp_adapters.pop(name, None)
```

`PluginManager.unload()` 改為同步清理 registry：

```python
async def unload(self, name: str) -> None:
    plugin, _ = self._plugins[name]
    # 清理此 plugin 曾注冊的 tools / hooks / mcp
    for tool_name in plugin.registered_tools:       # plugin 自行追蹤
        self._plugin_registry.remove_tool(tool_name)
    for hook_name in plugin.registered_hooks:
        self._plugin_registry.remove_hook(hook_name)
        self._hook_registry.unregister(hook_name)
    for mcp_name in plugin.registered_mcps:
        self._plugin_registry.remove_mcp(mcp_name)
    await plugin.on_disable()
    await plugin.on_unload()
    del self._plugins[name]
```

`BasePlugin` 需新增追蹤欄位（在 `waifu_types`）：

```python
class BasePlugin(ABC):
    registered_tools: List[str] = []   # on_load 時由 _PluginContextImpl 填入
    registered_hooks: List[str] = []
    registered_mcps:  List[str] = []
```

---

## 3. Plugin 資料夾與 importlib 載入

### 目錄位置

每個 plugin 必須是一個**資料夾**，根目錄放 `metadata.json`：

```
~/.waifu/
└── plugins/
    └── weather_plugin/
        ├── metadata.json     ← 必要：入口點、版本、config schema
        ├── __init__.py       ← 或 metadata.json entry 指定的模組
        └── utils.py
```

### metadata.json 格式

```json
{
  "name": "weather-plugin",
  "version": "1.0.0",
  "description": "提供天氣查詢工具",
  "entry": "weather_plugin.WeatherPlugin",
  "config_schema": {
    "type": "object",
    "properties": {
      "api_key": { "type": "string" },
      "unit":    { "type": "string", "enum": ["celsius", "fahrenheit"], "default": "celsius" }
    },
    "required": ["api_key"]
  }
}
```

| 欄位            | 必填 | 說明                                                             |
| --------------- | ---- | ---------------------------------------------------------------- |
| `name`          | ✅    | plugin 唯一名稱，對應 `BasePlugin.name`                          |
| `version`       | ✅    | semver 字串                                                      |
| `description`   | —    | 顯示在 UI                                                        |
| `entry`         | ✅    | `"{module}.{ClassName}"` 格式，module 相對於 plugin 資料夾根目錄 |
| `config_schema` | —    | JSON Schema，用於 UI 表單生成與 API 驗證                         |

`AppPaths` 新增：

```python
@property
def plugins_dir(self) -> Path:
    return self._base / "plugins"
```

### PluginLoader

`waifu/plugin/loader.py`：

```python
import importlib.util
import inspect
import json
from pathlib import Path
from typing import List
from waifu_types import BasePlugin


class PluginMeta:
    def __init__(self, dir: Path, data: dict) -> None:
        self.dir         = dir
        self.name        = data["name"]
        self.version     = data["version"]
        self.description = data.get("description", "")
        self.entry       = data["entry"]              # "module.ClassName"
        self.config_schema = data.get("config_schema", {})


class PluginLoader:
    def __init__(self, plugins_dir: Path) -> None:
        self._dir = plugins_dir

    def list_available(self) -> List[PluginMeta]:
        """掃描 plugins_dir，回傳所有含有效 metadata.json 的 plugin 清單"""
        result = []
        for p in self._dir.iterdir():
            meta_file = p / "metadata.json"
            if p.is_dir() and meta_file.exists():
                try:
                    result.append(PluginMeta(p, json.loads(meta_file.read_text())))
                except (KeyError, json.JSONDecodeError):
                    pass  # metadata 不合法，跳過
        return result

    def read_meta(self, plugin_name: str) -> PluginMeta:
        """讀取特定 plugin 的 metadata"""
        meta_file = self._dir / plugin_name / "metadata.json"
        if not meta_file.exists():
            raise FileNotFoundError(f"Plugin '{plugin_name}' not found or missing metadata.json")
        return PluginMeta(self._dir / plugin_name, json.loads(meta_file.read_text()))

    def resolve(self, plugin_name: str) -> BasePlugin:
        """
        從 metadata.json 的 entry 欄位載入 plugin 實例。
        entry 格式："{module}.{ClassName}"，module 從 plugin 資料夾根目錄解析。
        """
        meta = self.read_meta(plugin_name)
        module_path, class_name = meta.entry.rsplit(".", 1)

        # 將 plugin 資料夾加入 sys.path 確保相對 import 正常
        import sys
        plugin_dir = str(meta.dir.parent)
        if plugin_dir not in sys.path:
            sys.path.insert(0, plugin_dir)

        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name, None)
        if cls is None or not issubclass(cls, BasePlugin):
            raise ValueError(f"'{meta.entry}' is not a valid BasePlugin subclass")
        return cls()
```

---

## 4. 資料庫 Models

在 `waifu/store/models.py` 新增以下 tables，並加入 `_TABLES`。

### PluginConfig

```python
class PluginConfig(BaseModel):
    id          = CharField(primary_key=True, default=lambda: str(uuid.uuid4()))
    name        = CharField(unique=True)       # 來自 metadata.json["name"]
    plugin_name = CharField()                  # plugins_dir 下的資料夾名稱
    enabled     = BooleanField(default=True)
    config_json = TextField(default="{}")      # JSON dict，傳給 on_load
    installed_at = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "plugin_configs"
```

### MCPServer

```python
class MCPServer(BaseModel):
    id          = CharField(primary_key=True, default=lambda: str(uuid.uuid4()))
    name        = CharField(unique=True)
    type        = CharField()                  # "stdio" | "sse"
    command     = TextField(null=True)         # stdio: JSON array, e.g. '["npx","mcp-fs"]'
    url         = CharField(null=True)         # sse: http://...
    enabled     = BooleanField(default=True)
    config_json = TextField(default="{}")

    class Meta:
        table_name = "mcp_servers"
```

### AppConfig

```python
class AppConfig(BaseModel):
    key        = CharField(primary_key=True)   # e.g. "provider.model"
    value      = TextField()                   # JSON-encoded value
    updated_at = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "app_config"

    def save(self, *args, **kwargs):
        self.updated_at = datetime.utcnow()
        return super().save(*args, **kwargs)
```

**熱更新 key 範圍（`gateway.*` 需重啟，其餘即時生效）：**

| Key                              | 類型        | 熱更新   |
| -------------------------------- | ----------- | -------- |
| `provider.model`                 | str         | ✅        |
| `provider.temperature`           | float       | ✅        |
| `provider.max_tokens`            | int \| null | ✅        |
| `context.system_prompt_template` | str         | ✅        |
| `context.max_history_messages`   | int         | ✅        |
| `context.history_strategy`       | str         | ✅        |
| `gateway.session_ttl`            | int         | ❌ 需重啟 |
| `gateway.lane_max_queue`         | int         | ❌ 需重啟 |

### Character

```python
class Character(BaseModel):
    id          = CharField(primary_key=True, default=lambda: str(uuid.uuid4()))
    name        = CharField(unique=True)
    soul_path   = CharField()                  # 絕對路徑，指向 soul.md
    avatar_path = CharField(null=True)         # 絕對路徑，指向 avatar 圖檔
    live2d_dir  = CharField(null=True)         # 絕對路徑，指向 live2d/ 資料夾
    active      = BooleanField(default=False)  # 同時只有一個 active
    created_at  = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "characters"
```

### Relationship

```python
class Relationship(BaseModel):
    id           = CharField(primary_key=True, default=lambda: str(uuid.uuid4()))
    character    = ForeignKeyField(Character, backref="relationships", on_delete="CASCADE", column_name="character_id")
    user_id      = CharField()                 # e.g. "discord:user:123456"
    display_name = CharField()
    notes        = TextField(default="")       # markdown 格式，記住的事
    memory_path  = CharField(null=True)        # 指向 ~/.waifu/memory/{char}/direct/{user_id}.md
    updated_at   = DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "relationships"
        indexes = ((("character_id", "user_id"), True),)  # unique together

    def save(self, *args, **kwargs):
        self.updated_at = datetime.utcnow()
        return super().save(*args, **kwargs)
```

---

## 5. Repository 層與 Service 層

### 分層職責

```
API Router       薄層，只做 HTTP 轉換（parse body、回傳 response）
    ↓
Service 層       業務邏輯，協調 Repository + Runtime Manager
    ↓
Repository 層    純 DB CRUD，不知道 runtime 的存在
    ↓
Models           peewee ORM table 定義
```

---

### Repository 層

`waifu/store/repositories/` 下各檔案只做 DB 操作，不 import 任何 runtime 元件。

#### PluginRepository

```python
class PluginRepository:
    def create(self, name: str, plugin_name: str, config: dict) -> PluginConfig:
        return PluginConfig.create(
            name=name,
            plugin_name=plugin_name,
            config_json=json.dumps(config),
        )

    def delete(self, name: str) -> None:
        PluginConfig.delete().where(PluginConfig.name == name).execute()

    def set_enabled(self, name: str, enabled: bool) -> None:
        PluginConfig.update(enabled=enabled).where(PluginConfig.name == name).execute()

    def update_config(self, name: str, config: dict) -> None:
        PluginConfig.update(config_json=json.dumps(config)).where(PluginConfig.name == name).execute()

    def get(self, name: str) -> Optional[PluginConfig]:
        return PluginConfig.get_or_none(PluginConfig.name == name)

    def list_enabled(self) -> List[PluginConfig]:
        return list(PluginConfig.select().where(PluginConfig.enabled == True))

    def list_all(self) -> List[PluginConfig]:
        return list(PluginConfig.select())
```

#### MCPRepository

```python
class MCPRepository:
    def create(self, name: str, type: str, command, url, config: dict) -> MCPServer:
        return MCPServer.create(
            name=name, type=type,
            command=json.dumps(command) if command else None,
            url=url,
            config_json=json.dumps(config),
        )

    def delete(self, name: str) -> None:
        MCPServer.delete().where(MCPServer.name == name).execute()

    def set_enabled(self, name: str, enabled: bool) -> None:
        MCPServer.update(enabled=enabled).where(MCPServer.name == name).execute()

    def get(self, name: str) -> Optional[MCPServer]:
        return MCPServer.get_or_none(MCPServer.name == name)

    def list_enabled(self) -> List[MCPServer]:
        return list(MCPServer.select().where(MCPServer.enabled == True))

    def list_all(self) -> List[MCPServer]:
        return list(MCPServer.select())
```

#### AppConfigRepository

```python
class AppConfigRepository:
    def set(self, key: str, value) -> None:
        AppConfig.insert(key=key, value=json.dumps(value)) \
                 .on_conflict(action="REPLACE").execute()

    def get(self, key: str, default=None):
        row = AppConfig.get_or_none(AppConfig.key == key)
        return json.loads(row.value) if row else default

    def get_all(self) -> dict:
        return {r.key: json.loads(r.value) for r in AppConfig.select()}

    def delete(self, key: str) -> None:
        AppConfig.delete().where(AppConfig.key == key).execute()
```

#### CharacterRepository

```python
class CharacterRepository:
    def create(self, name: str, soul_path: str, avatar_path=None, live2d_dir=None) -> Character:
        return Character.create(name=name, soul_path=soul_path,
                                avatar_path=avatar_path, live2d_dir=live2d_dir)

    def get(self, id: str) -> Optional[Character]:
        return Character.get_or_none(Character.id == id)

    def get_active(self) -> Optional[Character]:
        return Character.get_or_none(Character.active == True)

    def set_active(self, id: str) -> None:
        Character.update(active=False).execute()                           # deactivate all
        Character.update(active=True).where(Character.id == id).execute()

    def update(self, id: str, **fields) -> None:
        Character.update(**fields).where(Character.id == id).execute()

    def delete(self, id: str) -> None:
        Character.delete().where(Character.id == id).execute()

    def list_all(self) -> List[Character]:
        return list(Character.select())


class RelationshipRepository:
    def get_or_create(self, character_id: str, user_id: str, display_name: str) -> Relationship:
        obj, _ = Relationship.get_or_create(
            character_id=character_id, user_id=user_id,
            defaults={"display_name": display_name},
        )
        return obj

    def update(self, character_id: str, user_id: str, **fields) -> None:
        Relationship.update(**fields).where(
            Relationship.character_id == character_id,
            Relationship.user_id == user_id,
        ).execute()

    def get(self, character_id: str, user_id: str) -> Optional[Relationship]:
        return Relationship.get_or_none(
            Relationship.character_id == character_id,
            Relationship.user_id == user_id,
        )

    def list_by_character(self, character_id: str) -> List[Relationship]:
        return list(Relationship.select().where(Relationship.character_id == character_id))
```

---

### Service 層

`waifu/service/` 下各檔案接收 Repository + Runtime Manager，處理業務邏輯。

#### PluginService

```python
class PluginService:
    def __init__(self, repo: PluginRepository, plugin_manager: PluginManager, loader: PluginLoader) -> None:
        self._repo = repo
        self._pm = plugin_manager
        self._loader = loader

    async def install(self, plugin_name: str, config: dict) -> PluginConfig:
        plugin = self._loader.resolve(plugin_name)
        await self._pm.load(plugin, config)
        return self._repo.create(plugin.name, plugin_name, config)

    async def uninstall(self, name: str) -> None:
        await self._pm.unload(name)
        self._repo.delete(name)

    async def enable(self, name: str) -> None:
        await self._pm.enable(name)
        self._repo.set_enabled(name, True)

    async def disable(self, name: str) -> None:
        await self._pm.disable(name)
        self._repo.set_enabled(name, False)

    def list_installed(self) -> List[dict]:
        return self._pm.list()

    def list_available(self) -> List[PluginMeta]:
        return self._loader.list_available()
```

#### MCPService

```python
class MCPService:
    def __init__(self, repo: MCPRepository, plugin_manager: PluginManager) -> None:
        self._repo = repo
        self._pm = plugin_manager

    async def add(self, name: str, type: str, command=None, url=None, config=None) -> MCPServer:
        adapter = self._build_adapter(type, command, url)
        await self._pm.load(MCPPlugin(name, adapter))
        return self._repo.create(name, type, command, url, config or {})

    async def remove(self, name: str) -> None:
        await self._pm.unload(name)
        self._repo.delete(name)

    async def enable(self, name: str) -> None:
        row = self._repo.get(name)
        adapter = self._build_adapter(row.type, json.loads(row.command or "null"), row.url)
        await self._pm.load(MCPPlugin(name, adapter))
        self._repo.set_enabled(name, True)

    async def disable(self, name: str) -> None:
        await self._pm.unload(name)
        self._repo.set_enabled(name, False)

    def list_all(self) -> List[MCPServer]:
        return self._repo.list_all()

    def _build_adapter(self, type, command, url):
        from waifu.mcp import StdioMCPAdapter, SSEMCPAdapter
        return StdioMCPAdapter(command) if type == "stdio" else SSEMCPAdapter(url)
```

#### AppConfigService

```python
class AppConfigService:
    _HOT_KEYS = {
        "provider.model", "provider.temperature", "provider.max_tokens",
        "context.system_prompt_template", "context.max_history_messages",
        "context.history_strategy",
    }

    def __init__(self, repo: AppConfigRepository, context_builder: ContextBuilder, agent_runner: AgentRunner) -> None:
        self._repo = repo
        self._cb = context_builder
        self._ar = agent_runner

    def get_all(self) -> dict:
        return self._repo.get_all()

    def set(self, key: str, value) -> None:
        self._repo.set(key, value)
        if key in self._HOT_KEYS:
            self._apply_hot(key, value)

    def _apply_hot(self, key: str, value) -> None:
        section, field = key.split(".", 1)
        if section == "context":
            setattr(self._cb.config, field, value)
        elif section == "provider":
            setattr(self._ar.provider, field, value)
```

#### CharacterService

```python
class CharacterService:
    def __init__(self, char_repo: CharacterRepository, rel_repo: RelationshipRepository) -> None:
        self._chars = char_repo
        self._rels = rel_repo

    def create(self, name, soul_path, avatar_path=None, live2d_dir=None) -> Character:
        return self._chars.create(name, soul_path, avatar_path, live2d_dir)

    def activate(self, id: str) -> None:
        self._chars.set_active(id)

    def get_active(self) -> Optional[Character]:
        return self._chars.get_active()

    def list_all(self) -> List[Character]:
        return self._chars.list_all()

    def update(self, id: str, **fields) -> None:
        self._chars.update(id, **fields)

    def delete(self, id: str) -> None:
        self._chars.delete(id)

    def get_relationship(self, character_id: str, user_id: str, display_name: str) -> Relationship:
        return self._rels.get_or_create(character_id, user_id, display_name)

    def update_relationship(self, character_id: str, user_id: str, **fields) -> None:
        self._rels.update(character_id, user_id, **fields)

    def list_relationships(self, character_id: str) -> List[Relationship]:
        return self._rels.list_by_character(character_id)
```

---

## 6. API 端點設計

### Plugin API

```
GET    /plugins                    列出已安裝的 plugins（PluginManager.list()）
GET    /plugins/available          列出 plugins_dir 中可用的 plugin（含 metadata）
POST   /plugins                    安裝並載入 plugin
         body: { plugin_name, config? }    ← plugin_name = 資料夾名稱
POST   /plugins/{name}/enable      啟用
POST   /plugins/{name}/disable     停用
DELETE /plugins/{name}             卸載並從 DB 刪除
PUT    /plugins/{name}/config      更新 config（重新 reload plugin）
         body: { config }
```

### MCP API

```
GET    /mcp                        列出所有 MCP servers
POST   /mcp                        新增並連線 MCP server
         body: { name, type, command?, url?, config? }
POST   /mcp/{name}/enable          啟用（重新連線）
POST   /mcp/{name}/disable         停用（斷線）
DELETE /mcp/{name}                 刪除
PUT    /mcp/{name}                 更新設定（斷線重連）
```

### Config API

```
GET    /config                     取得所有 AppConfig（含 hot/cold 標記）
PUT    /config                     批次更新
         body: { "provider.model": "gpt-4o", "context.max_history_messages": 30 }
GET    /config/{key}               取得單一值
PUT    /config/{key}               更新單一值
```

### Character API

```
GET    /characters                 列出所有角色
POST   /characters                 建立角色
         body: { name, soul_path, avatar_path?, live2d_dir? }
GET    /characters/{id}            取得角色詳情
PUT    /characters/{id}            更新角色設定
DELETE /characters/{id}            刪除角色
POST   /characters/{id}/activate   設為 active（其他角色自動 deactivate）

GET    /characters/{id}/relationships         列出此角色與所有用戶的關係
GET    /characters/{id}/relationships/{uid}   取得單一關係
PUT    /characters/{id}/relationships/{uid}   更新關係（親密度、備註）
```

---

## 7. AppConfig 熱更新

`ContextBuilder` 目前持有一份 `ContextConfig`（immutable）。改為持有可變引用：

```python
class ContextBuilder:
    def __init__(self, config: ContextConfig) -> None:
        self.config = config   # 改為 public，AppConfigService 直接 setattr
```

`AgentRunner` 同理，`self.provider` 的 `model` / `temperature` 欄位直接覆寫即可（hai `ProviderText` 支援）。

**不可熱更新的設定**（`gateway.*`）在 `PUT /config` 時回傳：
```json
{ "key": "gateway.session_ttl", "status": "saved", "note": "requires restart" }
```

---

## 8. 角色與記憶 Models

詳細格式見 `ARCHITECTURE角色.md`。

DB 層（`Character` / `Relationship`）與檔案層（`~/.waifu/memory/`）的職責分工：

| 資料                        | 儲存位置                        | 原因                       |
| --------------------------- | ------------------------------- | -------------------------- |
| 角色清單、active 狀態、路徑 | DB `characters`                 | 查詢快、API 友善           |
| 親密度、用戶備註            | DB `relationships`              | 結構化、可查詢             |
| 對話歷史（近期原文）        | `memory/{char}/direct/{uid}.md` | 大量文字，DB 不適合        |
| 舊對話摘要                  | 同上 md 檔案                    | 與原文同一份，好維護       |
| soul.md / avatar / live2d   | 檔案系統                        | Binary / Markdown，不入 DB |

---

## 9. 啟動時初始化流程

`Waifu.start()` 呼叫前，透過 Service 層（而非直接查 Model）還原 runtime 狀態：

```python
async def _restore_from_db(self) -> None:
    """從 DB 恢復所有持久化設定到 runtime"""

    # 1. AppConfig → 套用到 ContextBuilder / AgentRunner
    for key, value in self._config_service.get_all().items():
        self._config_service.set(key, value)          # 觸發 hot-apply

    # 2. Enabled MCP servers → 重新連線
    for row in self._mcp_repo.list_enabled():
        cmd = json.loads(row.command) if row.command else None
        await self._mcp_service.add(row.name, row.type, cmd, row.url, {})

    # 3. Enabled plugins → 重新載入
    for row in self._plugin_repo.list_enabled():
        config = json.loads(row.config_json)
        await self._plugin_service.install(row.plugin_name, config)
```

---

## 10. 完整目錄結構（新增部分）

```
waifu/
├── plugin/
│   ├── __init__.py         PluginManager, PluginRegistry（補 remove_* 方法）
│   ├── builtin.py          ToolPlugin, HookPlugin, MCPPlugin, WaifuNodePlugin
│   └── loader.py           PluginLoader + PluginMeta            ← 新增
│
├── store/
│   ├── models.py           + PluginConfig, MCPServer, AppConfig,
│   │                         Character, Relationship             ← 擴充
│   └── repositories/                                            ← 新增
│       ├── __init__.py
│       ├── plugin.py       PluginRepository
│       ├── mcp.py          MCPRepository
│       ├── config.py       AppConfigRepository
│       └── character.py    CharacterRepository, RelationshipRepository
│
├── service/                                                     ← 新增
│   ├── __init__.py
│   ├── plugin.py           PluginService
│   ├── mcp.py              MCPService
│   ├── config.py           AppConfigService
│   └── character.py        CharacterService
│   ├── plugin_service.py   PluginService                        ← 新增
│   ├── mcp_service.py      MCPService                           ← 新增
│   ├── config_service.py   AppConfigService                     ← 新增
│   └── character_service.py CharacterService, RelationshipService ← 新增
│
└── router/
    ├── plugin.py           擴充：POST /plugins, PUT /plugins/{name}/config
    ├── mcp.py              MCPServer CRUD                        ← 新增
    ├── config.py           AppConfig GET/PUT                     ← 新增
    └── character.py        Character + Relationship CRUD         ← 新增
```
