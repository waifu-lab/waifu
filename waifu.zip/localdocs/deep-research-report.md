## 實作範例

下面三個範例共用一個基礎模組 `st_cards.py`。這個模組支援：

- 讀取 `.png`、`.json`、`.yaml/.yml`、`.charx`
- PNG 內優先讀 `ccv3`，否則退回 `chara`
- 把 V1、V2、V3、YAML 交換格式、舊 Pygmalion/Gradio JSON 正規化成同一個 Pydantic 模型
- 產生去重用 fingerprint

這個設計直接對應 SillyTavern 現行程式碼的格式分流與讀取優先序。

### 共用基礎模組

先建立 `st_cards.py`：

```python
from __future__ import annotations

import base64
import hashlib
import json
import struct
import zipfile
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator

PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"
SUPPORTED_SUFFIXES = {".png", ".json", ".yml", ".yaml", ".charx"}


class CardError(Exception):
    """Base class for card errors."""


class UnsupportedFormatError(CardError):
    """Raised when file format is not supported."""


class CardParseError(CardError):
    """Raised when file content cannot be parsed."""


class NormalizedCard(BaseModel):
    source_path: Path
    source_format: Literal["png", "json", "yaml", "charx"]
    spec: str
    spec_version: str | None = None

    name: str
    description: str = ""
    personality: str = ""
    scenario: str = ""
    first_mes: str = ""
    mes_example: str = ""

    creator_notes: str = ""
    system_prompt: str = ""
    post_history_instructions: str = ""
    alternate_greetings: list[str] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    creator: str = ""
    character_version: str = ""

    raw: dict[str, Any] = Field(default_factory=dict, repr=False)

    @field_validator("tags", mode="before")
    @classmethod
    def normalize_tags(cls, value: Any) -> list[str]:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(x).strip() for x in value if str(x).strip()]
        if isinstance(value, str):
            return [x.strip() for x in value.split(",") if x.strip()]
        return [str(value).strip()]

    @field_validator("alternate_greetings", mode="before")
    @classmethod
    def normalize_alt_greetings(cls, value: Any) -> list[str]:
        if value is None:
            return []
        if isinstance(value, list):
            return [str(x) for x in value]
        if isinstance(value, str):
            return [value]
        return [str(value)]


def _iter_png_chunks(data: bytes):
    if not data.startswith(PNG_SIGNATURE):
        raise CardParseError("不是有效的 PNG 檔案。")
    i = len(PNG_SIGNATURE)
    data_len = len(data)

    while i + 12 <= data_len:
        length = struct.unpack(">I", data[i:i + 4])[0]
        i += 4
        chunk_type = data[i:i + 4].decode("latin-1")
        i += 4
        chunk_data = data[i:i + length]
        i += length
        _crc = data[i:i + 4]
        i += 4
        yield chunk_type, chunk_data
        if chunk_type == "IEND":
            break


def _extract_png_card_payload(path: Path) -> str:
    data = path.read_bytes()
    text_chunks: dict[str, str] = {}

    for chunk_type, chunk_data in _iter_png_chunks(data):
        if chunk_type != "tEXt":
            continue
        if b"\x00" not in chunk_data:
            continue
        keyword, text = chunk_data.split(b"\x00", 1)
        key = keyword.decode("latin-1", errors="ignore").lower().strip()
        text_chunks[key] = text.decode("latin-1", errors="ignore")

    # Prefer CCV3 over chara, matching current ST behavior.
    for key in ("ccv3", "chara"):
        if key in text_chunks:
            try:
                return base64.b64decode(text_chunks[key]).decode("utf-8")
            except Exception as exc:
                raise CardParseError(f"PNG metadata Base64/UTF-8 解碼失敗: {exc}") from exc

    raise CardParseError("PNG 中找不到 ccv3 或 chara tEXt chunk。")


def _extract_charx_payload(path: Path) -> dict[str, Any]:
    try:
        with zipfile.ZipFile(path, "r") as zf:
            # Current CharX spec expects card.json at archive root.
            raw = zf.read("card.json")
    except KeyError as exc:
        raise CardParseError("CHARX 找不到 card.json。") from exc
    except zipfile.BadZipFile as exc:
        raise CardParseError("不是有效的 CHARX/ZIP 檔案。") from exc

    try:
        return json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise CardParseError(f"CHARX card.json 解析失敗: {exc}") from exc


def _load_raw(path: Path) -> tuple[dict[str, Any], str]:
    suffix = path.suffix.lower()

    if suffix == ".png":
        payload = _extract_png_card_payload(path)
        try:
            return json.loads(payload), "png"
        except json.JSONDecodeError as exc:
            raise CardParseError(f"PNG 內嵌 JSON 解析失敗: {exc}") from exc

    if suffix == ".json":
        try:
            return json.loads(path.read_text(encoding="utf-8")), "json"
        except json.JSONDecodeError as exc:
            raise CardParseError(f"JSON 解析失敗: {exc}") from exc

    if suffix in {".yml", ".yaml"}:
        try:
            obj = yaml.safe_load(path.read_text(encoding="utf-8"))
        except yaml.YAMLError as exc:
            raise CardParseError(f"YAML 解析失敗: {exc}") from exc
        if not isinstance(obj, dict):
            raise CardParseError("YAML 根節點必須是 mapping/object。")
        return obj, "yaml"

    if suffix == ".charx":
        return _extract_charx_payload(path), "charx"

    raise UnsupportedFormatError(f"不支援的副檔名: {suffix}")


def _normalize_v_spec(raw: dict[str, Any], source_path: Path, source_format: str) -> NormalizedCard:
    spec = raw.get("spec")
    data = raw.get("data", {}) if isinstance(raw.get("data"), dict) else {}

    if spec in {"chara_card_v2", "chara_card_v3"} and data:
        return NormalizedCard(
            source_path=source_path,
            source_format=source_format,  # type: ignore[arg-type]
            spec=spec,
            spec_version=str(raw.get("spec_version")) if raw.get("spec_version") is not None else None,
            name=str(data.get("name", raw.get("name", ""))).strip(),
            description=str(data.get("description", "")),
            personality=str(data.get("personality", "")),
            scenario=str(data.get("scenario", "")),
            first_mes=str(data.get("first_mes", "")),
            mes_example=str(data.get("mes_example", "")),
            creator_notes=str(data.get("creator_notes", "")),
            system_prompt=str(data.get("system_prompt", "")),
            post_history_instructions=str(data.get("post_history_instructions", "")),
            alternate_greetings=data.get("alternate_greetings", []),
            tags=data.get("tags", []),
            creator=str(data.get("creator", "")),
            character_version=str(data.get("character_version", "")),
            raw=raw,
        )

    # Tavern / legacy V1-style JSON
    if "name" in raw and "first_mes" in raw:
        return NormalizedCard(
            source_path=source_path,
            source_format=source_format,  # type: ignore[arg-type]
            spec="tavern_card_v1",
            spec_version=None,
            name=str(raw.get("name", "")).strip(),
            description=str(raw.get("description", "")),
            personality=str(raw.get("personality", "")),
            scenario=str(raw.get("scenario", "")),
            first_mes=str(raw.get("first_mes", "")),
            mes_example=str(raw.get("mes_example", "")),
            creator_notes=str(raw.get("creatorcomment", raw.get("creator_notes", ""))),
            tags=raw.get("tags", []),
            creator=str(raw.get("creator", "")),
            raw=raw,
        )

    # Older Pygmalion/Gradio-style JSON
    if "char_name" in raw:
        return NormalizedCard(
            source_path=source_path,
            source_format=source_format,  # type: ignore[arg-type]
            spec="pygmalion_gradio",
            spec_version=None,
            name=str(raw.get("char_name", "")).strip(),
            description=str(raw.get("char_persona", "")),
            personality="",
            scenario=str(raw.get("world_scenario", "")),
            first_mes=str(raw.get("char_greeting", "")),
            mes_example=str(raw.get("example_dialogue", "")),
            creator_notes=str(raw.get("creatorcomment", raw.get("creator_notes", ""))),
            tags=raw.get("tags", []),
            creator=str(raw.get("creator", "")),
            raw=raw,
        )

    # Current ST YAML import path expects name/context/greeting.
    if "name" in raw and ("context" in raw or "greeting" in raw):
        return NormalizedCard(
            source_path=source_path,
            source_format=source_format,  # type: ignore[arg-type]
            spec="yaml_interchange",
            spec_version=None,
            name=str(raw.get("name", "")).strip(),
            description=str(raw.get("context", "")),
            first_mes=str(raw.get("greeting", "")),
            raw=raw,
        )

    raise CardParseError("無法辨識的卡片資料結構。")


def load_card(path: str | Path) -> NormalizedCard:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"檔案不存在: {p}")
    raw, source_format = _load_raw(p)
    card = _normalize_v_spec(raw, p, source_format)
    if not card.name:
        raise CardParseError("卡片缺少角色名稱。")
    return card


def card_fingerprint(card: NormalizedCard) -> str:
    # Use normalized, content-centric fields instead of filename.
    payload = {
        "spec": card.spec,
        "spec_version": card.spec_version,
        "name": card.name,
        "description": card.description,
        "personality": card.personality,
        "scenario": card.scenario,
        "first_mes": card.first_mes,
        "mes_example": card.mes_example,
        "creator_notes": card.creator_notes,
        "system_prompt": card.system_prompt,
        "post_history_instructions": card.post_history_instructions,
        "alternate_greetings": card.alternate_greetings,
        "tags": card.tags,
        "creator": card.creator,
        "character_version": card.character_version,
    }
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def iter_card_files(root: str | Path):
    base = Path(root).expanduser().resolve()
    for path in base.rglob("*"):
        if path.is_file() and path.suffix.lower() in SUPPORTED_SUFFIXES:
            yield path
```

**單檔載入範例**

建立 `demo_single.py`：

```python
from __future__ import annotations

import sys
from st_cards import load_card, CardError

def main() -> int:
    if len(sys.argv) != 2:
        print("用法: python demo_single.py /path/to/card.png")
        return 2

    path = sys.argv[1]

    try:
        card = load_card(path)
    except FileNotFoundError as exc:
        print(f"[ERROR] {exc}")
        return 1
    except CardError as exc:
        print(f"[ERROR] 解析失敗: {exc}")
        return 1

    dump = card.model_dump(exclude={"raw"})
    print("=== 解析成功 ===")
    for key, value in dump.items():
        print(f"{key}: {value}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
```

**執行方式**

```bash
python demo_single.py "./data/default-user/characters/Alice.png"
```

**輸出範例**

```text
=== 解析成功 ===
source_path: /full/path/data/default-user/characters/Alice.png
source_format: png
spec: chara_card_v3
spec_version: 3.0
name: Alice
description: ...
personality: ...
scenario: ...
first_mes: Hello there!
mes_example: ...
creator_notes: ...
system_prompt: ...
post_history_instructions: ...
alternate_greetings: ['Hi!', 'Good to see you.']
tags: ['fantasy', 'merchant']
creator: demo-author
character_version: 1.2
```

**常見問題排解**

若出現「找不到 `ccv3` 或 `chara`」，通常表示這不是 SillyTavern/Tavern 生態常見的 PNG 卡，或檔案在搬移時被某些圖片工具移除了 metadata。若出現 `JSON 解析失敗`，表示 chunk 存在但內容不是合法 JSON；這在手工編修嵌入資料時很常見。若檔案是 `.json`／`.yaml` 而不是 `.png`，請確認它是交換格式而非聊天紀錄檔。SillyTavern 現行程式碼對角色匯入的 JSON 也會區分規格化 JSON、V1 JSON 與 Pygmalion/Gradio JSON；本模組已模擬這種多分支判斷。

**批次合併與去重範例**

建立 `merge_cards.py`：

```python
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

from st_cards import iter_card_files, load_card, card_fingerprint, CardError

def main() -> int:
    if len(sys.argv) not in {2, 3}:
        print("用法: python merge_cards.py <cards_root> [output_json]")
        return 2

    root = Path(sys.argv[1])
    out = Path(sys.argv[2]) if len(sys.argv) == 3 else Path("merged_cards.json")

    unique_cards = {}
    duplicate_sources = defaultdict(list)
    failed = []

    for path in iter_card_files(root):
        try:
            card = load_card(path)
            fp = card_fingerprint(card)
        except (CardError, FileNotFoundError) as exc:
            failed.append({"path": str(path), "error": str(exc)})
            continue

        if fp in unique_cards:
            duplicate_sources[fp].append(str(path))
            continue

        unique_cards[fp] = {
            "card": card,
            "sources": [str(path)],
        }

    merged = []
    for fp, item in unique_cards.items():
        card = item["card"]
        payload = card.model_dump(exclude={"raw"})
        payload["fingerprint"] = fp
        payload["sources"] = item["sources"] + duplicate_sources.get(fp, [])
        merged.append(payload)

    out.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"掃描完成: {root}")
    print(f"唯一卡片數: {len(unique_cards)}")
    print(f"重複群組數: {len(duplicate_sources)}")
    print(f"失敗數: {len(failed)}")
    print(f"輸出檔案: {out.resolve()}")

    if failed:
        failed_path = out.with_suffix(".failed.json")
        failed_path.write_text(json.dumps(failed, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"失敗明細: {failed_path.resolve()}")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
```

**執行方式**

```bash
python merge_cards.py "./data/default-user/characters" "./merged_cards.json"
```

**輸出範例**

```text
掃描完成: data/default-user/characters
唯一卡片數: 128
重複群組數: 14
失敗數: 3
輸出檔案: /full/path/merged_cards.json
失敗明細: /full/path/merged_cards.failed.json
```

