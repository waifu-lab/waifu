# waifu-node

Waifu 的本機電腦控制節點。
作為獨立 Rust binary 存在於 Cargo workspace 中，由 Tauri app 負責安裝與生命週期管理。

---

## 定位

- **角色**：WS client，連線到 waifu backend
- **不開任何 server**，純粹等待後端下指令並執行
- 提供 waifu backend 操控本機電腦的能力（截圖、指令、系統資訊、輸入控制等）
- 本身沒有 AI 功能，是 waifu 的能力延伸
- 與 `src-tauri` 共用同一個 Cargo workspace，共用 `waifu-shared` 型別 crate

```
waifu-node ──WS / IPC──► waifu backend（server /node）
              連線後宣告能力與 tool schema，等待 invoke，回傳 result
              也可主動呼叫 waifu 已注冊的 tools（雙向）
```

---

## 連線模式

waifu-node 支援兩種傳輸模式，透過 `--mode` 指定：

### `ws` 模式（預設）

直接連線到後端，適用於**無頭機器（headless）**或獨立部署情境。

```
waifu-node ──WS──► Backend /node
```

### `ipc` 模式

透過本機 IPC 通道，由 Tauri 代理連線，適用於**有 Tauri App 管理**的情境。
訊息格式完全不變，只有底層傳輸層不同，Tauri 負責與後端的實際 WS 連線。

```
waifu-node ──IPC──► Tauri ──WS──► Backend /ws（multiplexed）
```

IPC 通道：
- Windows：Named Pipe `\\.\pipe\waifu-node`
- macOS / Linux：Unix Domain Socket `/tmp/waifu-node.sock`

> **規則**：IPC 模式下 waifu-node 送出/收到的 JSON 訊息格式與 ws 模式完全相同，
> 差異僅在 Tauri 會將訊息包裝為 `node_proxy` 類型後才送往後端。

---

## Cargo Workspace 結構

```
Yori-AI/
├── Cargo.toml               # workspace root
├── src-tauri/               # Tauri app
├── waifu-shared/            # 共用型別（NodeMessage 等）
│   └── src/lib.rs
└── waifu-node/              # 本 crate
    ├── Cargo.toml
    └── src/
        ├── main.rs          # 入口：CLI 參數、連線、主迴圈
        ├── conn.rs          # WS / IPC 連線管理、重連邏輯
        ├── dispatch.rs      # 接收 node_invoke，路由到對應 capability
        ├── tools.rs         # 產生 tool schema 清單（隨 caps + 已安裝 skills 動態組合）
        ├── skill/
        │   ├── mod.rs
        │   ├── sync.rs      # skill 檔案同步（HTTP pull，sha256 增量）
        │   └── registry.rs  # 本地 skill 掃描與清單維護
        └── capability/
            ├── mod.rs
            ├── screen.rs
            ├── exec.rs
            ├── sysinfo.rs
            ├── audio.rs
            └── input.rs
```

---

## 通訊協議

協議建立在 WebSocket 之上（ws 模式）或 IPC 之上（ipc 模式），所有訊息為 JSON，`type` 欄位必填。
端點（ws 模式）：`ws://<host>:<port>/node`（預設 `ws://127.0.0.1:8765/node`）

---

### 連線生命週期

```
waifu-node                    waifu backend
     │                              │
     │── connect ──────────────────►│
     │                              │
     │── node_hello ───────────────►│  宣告身份、版本、能力、tool schema
     │                              │  以及本機已安裝的 skills 與 skills_dir
     │                              │
     │◄─ node_welcome ──────────────│  接受連線
     │    或                        │
     │◄─ node_reject ───────────────│  拒絕（版本不符、token 錯誤）
     │                              │
     │         ... ready ...        │
     │                              │
     │◄─ node_skill_sync ───────────│  通知需同步的 skill 檔案清單
     │── node_skill_ready ─────────►│  同步完成確認
     │    或                        │
     │── node_skill_sync_error ────►│  同步失敗（磁碟空間不足等）
     │                              │
     │◄─ node_invoke ───────────────│  呼叫 node 能力（含 skill 的 exec）
     │── node_result ──────────────►│  回傳結果
     │                              │
     │── node_tool_call ───────────►│  node 呼叫 waifu tool（雙向）
     │◄─ node_tool_result ──────────│  waifu 回傳 tool 執行結果
     │                              │
     │◄─ node_ping ─────────────────│  每 30s
     │── node_pong ────────────────►│
     │                              │
     │── node_bye ────────────────►│  主動斷線（可選）
     │                              │
     ╳                              │  連線關閉，waifu 等待重連
```

---

### 訊息定義

#### `node_hello`（node → waifu）

連線成功後立即送出。

```jsonc
{
  "type": "node_hello",
  "protocol": "1",
  "version": "0.1.0",
  "token": "",
  "node_id": "<uuid>",
  "platform": "windows",       // "windows" | "macos" | "linux"
  "display_name": "home-pc",   // 多 node 情境下用於工具命名，如 exec@home-pc
  "caps": ["screen", "exec", "sysinfo", "audio", "input"],

  // skill 相關
  "skills_dir": "C:\\Users\\User\\AppData\\Roaming\\waifu\\skills",
  // waifu-node 本機 skill 根路徑，LLM 組裝 exec 指令時使用
  "installed_skills": [
    { "skill_id": "ocr-skill",   "version": "1.2.0" },
    { "skill_id": "auto-typer",  "version": "0.5.1" }
  ],
  // 啟動時掃描 skills_dir 取得，尚未同步的 skill 不列入

  "tools": [
    // capability tools（同原始定義，略）
    // skill tools 在 node_skill_ready 後由後端動態注冊，node_hello 不需帶入
    { "name": "screenshot",  ... },
    { "name": "exec",        ... },
    { "name": "sysinfo",     ... },
    { "name": "audio_devices", ... },
    { "name": "key_press",   ... },
    { "name": "key_down",    ... },
    { "name": "key_up",      ... },
    { "name": "mouse_move",  ... },
    { "name": "mouse_click", ... },
    { "name": "mouse_scroll", ... },
    { "name": "type_text",   ... }
  ]
}
```

> `display_name` 規則：只有一台 node 連線時後端沿用原始 tool 名稱（`exec`）；
> 多台連線時後端自動以 `exec@home-pc` 格式命名，避免衝突。

---

#### `node_welcome`（waifu → node）

```jsonc
{
  "type": "node_welcome",
  "session_id": "<uuid>",
  "accepted_caps": ["screen", "exec", "sysinfo", "audio", "input"],
  "accepted_tools": ["screenshot", "exec", ...]
}
```

---

#### `node_reject`（waifu → node）

```jsonc
{
  "type": "node_reject",
  "code": "AUTH_FAILED",
  "reason": "invalid token"
}
```

---

#### `node_skill_sync`（waifu → node）

後端安裝新 skill 或發現版本差異時送出。
只同步 `scripts/` 與 `assets/`；`SKILL.md` 留在後端供 LLM 讀取，不傳至 node。

```jsonc
{
  "type": "node_skill_sync",
  "skill_id": "ocr-skill",
  "version": "1.2.0",
  "base_url": "http://127.0.0.1:8765",   // 後端 HTTP 基底 URL，用於下載檔案
  "files": [
    {
      "path": "scripts/run.py",
      "sha256": "abc123...",
      "size": 2048
    },
    {
      "path": "assets/template.png",
      "sha256": "def456...",
      "size": 45000
    }
  ]
}
```

**同步邏輯**：

1. 對每個 `files[]` 條目，比對本地 `{skills_dir}/{skill_id}/{path}` 的 sha256
2. 相符者跳過；不存在或 sha256 不符者透過 HTTP 下載：
   `GET {base_url}/skills/{skill_id}/files/{path}`（支援 `Range` header 斷點續傳）
3. 寫入本地 `{skills_dir}/{skill_id}/{path}`
4. 全部完成後送出 `node_skill_ready`

---

#### `node_skill_ready`（node → waifu）

```jsonc
{
  "type": "node_skill_ready",
  "skill_id": "ocr-skill",
  "version": "1.2.0"
}
```

---

#### `node_skill_sync_error`（node → waifu）

```jsonc
{
  "type": "node_skill_sync_error",
  "skill_id": "ocr-skill",
  "code": "DISK_FULL",        // "DISK_FULL" | "DOWNLOAD_FAILED" | "CHECKSUM_MISMATCH"
  "message": "not enough disk space"
}
```

---

#### `node_invoke`（waifu → node）

```jsonc
{
  "type": "node_invoke",
  "request_id": "<uuid>",
  "action": "<tool name>",
  "params": { ... }
}
```

skill 的腳本執行同樣透過既有的 `exec` action，後端 LLM 自行組裝路徑：

```jsonc
{
  "type": "node_invoke",
  "request_id": "<uuid>",
  "action": "exec",
  "params": {
    "cmd": "python",
    "args": ["C:\\...\\waifu\\skills\\ocr-skill\\scripts\\run.py"],
    "timeout_ms": 30000
  }
}
```

---

#### `node_result`（node → waifu）

```jsonc
// 成功
{ "type": "node_result", "request_id": "<uuid>", "ok": true,  "data": { ... } }

// 失敗
{ "type": "node_result", "request_id": "<uuid>", "ok": false, "error": { "code": "...", "message": "..." } }
```

---

#### `node_tool_call` / `node_tool_result`（雙向，同原始定義）

```jsonc
// node → waifu
{ "type": "node_tool_call",   "request_id": "<uuid>", "tool": "shell", "params": { ... } }

// waifu → node
{ "type": "node_tool_result", "request_id": "<uuid>", "ok": true, "data": "..." }
```

---

#### `node_ping` / `node_pong` / `node_bye`（同原始定義）

```jsonc
{ "type": "node_ping", "ts": 1713110400000 }
{ "type": "node_pong", "ts": 1713110400000 }
{ "type": "node_bye",  "reason": "shutdown" }
```

---

### 錯誤代碼表（新增項目）

| code                        | 觸發方 | 說明                             |
| --------------------------- | ------ | -------------------------------- |
| `AUTH_FAILED`               | waifu  | token 不符                       |
| `PROTOCOL_VERSION_MISMATCH` | waifu  | `protocol` 版本不支援            |
| `CAP_NOT_SUPPORTED`         | node   | 呼叫了未宣告的 capability        |
| `INVALID_ACTION`            | node   | action 名稱不存在                |
| `INVALID_PARAMS`            | node   | params 格式錯誤                  |
| `EXEC_TIMEOUT`              | node   | exec 超時                        |
| `EXEC_FAILED`               | node   | 執行失敗（process 無法啟動）     |
| `SCREENSHOT_FAILED`         | node   | 截圖失敗                         |
| `INPUT_FAILED`              | node   | 輸入控制失敗                     |
| `DISK_FULL`                 | node   | skill 同步時磁碟空間不足         |
| `DOWNLOAD_FAILED`           | node   | skill 檔案下載失敗               |
| `CHECKSUM_MISMATCH`         | node   | skill 檔案 sha256 驗證失敗       |
| `NODE_DISCONNECTED`         | waifu  | invoke 時 node 已離線            |
| `INVOKE_TIMEOUT`            | waifu  | node 未在時限內回應              |
| `TOOL_ERROR`                | waifu  | node_tool_call 執行失敗          |
| `NOT_SUPPORTED`             | waifu  | tool executor 未設定             |
| `NO_NODE`                   | waifu  | 此 session 沒有綁定的 waifu-node |

---

## CLI 參數

```
waifu-node [OPTIONS]

OPTIONS:
  --mode <MODE>          連線模式：ws（預設）| ipc
  --backend-url <URL>    waifu backend WS 位址（ws 模式用，預設: ws://127.0.0.1:8765/node）
  --display-name <NAME>  多 node 情境下的識別名稱（預設: hostname）
  --token <TOKEN>        認證 token（預設: 空字串）
  --reconnect-ms <MS>    初始重連間隔毫秒（預設: 3000）
  --version              顯示版本號
  --help                 顯示說明
```

---

## Skill 本地目錄結構

```
{AppData}/waifu/skills/
├── ocr-skill/
│   ├── .manifest.json       # 已安裝版本記錄（waifu-node 維護，非原始 manifest）
│   ├── scripts/
│   │   └── run.py
│   └── assets/
│       └── template.png
└── auto-typer/
    ├── .manifest.json
    └── scripts/
        └── type.py
```

`.manifest.json`（waifu-node 本地維護）：

```jsonc
{
  "skill_id": "ocr-skill",
  "version": "1.2.0",
  "synced_at": "2026-04-14T10:00:00Z",
  "files": [
    { "path": "scripts/run.py",     "sha256": "abc123..." },
    { "path": "assets/template.png","sha256": "def456..." }
  ]
}
```

---

## 重連機制

連線斷開時自動重連，採用指數退避：

```
第 1 次重連：等 3s
第 2 次重連：等 6s
第 3 次重連：等 12s
...
上限：60s
```

重連時重新送 `node_hello`（`node_id` 保持不變，`installed_skills` 重新掃描）。

---

## 依賴 crate

| crate                  | 版本      | 用途                             |
| ---------------------- | --------- | -------------------------------- |
| `tokio`                | 1         | async runtime                    |
| `tokio-tungstenite`    | 0.21      | WebSocket client（ws 模式）      |
| `serde` / `serde_json` | 1         | JSON 序列化                      |
| `xcap`                 | latest    | 跨平台畫面擷取                   |
| `cpal`                 | 0.15      | 跨平台音訊裝置存取               |
| `sysinfo`              | 0.30      | CPU / 記憶體 / 磁碟 / 網路       |
| `enigo`                | 0.2       | 跨平台鍵盤 / 滑鼠控制            |
| `reqwest`              | 0.12      | skill 檔案 HTTP 下載（含 Range） |
| `sha2`                 | 0.10      | sha256 檔案驗證                  |
| `anyhow`               | 1         | 錯誤處理                         |
| `clap`                 | 4         | CLI 參數解析                     |
| `waifu-shared`         | workspace | 共用訊息型別                     |