# Waifu System Architecture

# 使用Dependency Injection的架構來開發

## 現有專案結構

```
waifu/                         # monorepo root
├── waifu/                     # 主套件（pyproject: fastapi）
│   ├── agent/                 # 空
│   ├── cli/                   # 空
│   ├── config/                # 空
│   ├── gateway/               # 空
│   ├── hook/                  # 空
│   ├── mcp/                   # 空
│   ├── plugin/                # 空
│   ├── router/                # 空
│   ├── tool/                  # 空
│   └── waifu.py               # 空
│
├── waifu-sdk/                 # SDK 套件（uv workspace member）
│   └── waifu-sdk/__init__.py
│
├── shuvi/                     # Agent 實作（已完成）
│   ├── agent.py               # Agent + inner/outer loop
│   └── types.py               # AgentConfig, AgentResult, ExecutionTrace
│
├── hai/                       # 基礎框架（已完成）
│   ├── providers/             # OpenAI / Anthropic / Google / Ollama
│   ├── tool/                  # Tool + @tool decorator
│   ├── core/                  # BaseNode, Flow, Document
│   ├── loader/                # text, csv, json, markdown, web
│   ├── processor/             # splitter, chunker, metadata_extractor
│   ├── vectorstores/qdrant/
│   └── graphstores/neo4j/
│
└── pyproject.toml             # UV workspace，依賴 fastapi
```

---

## 總體架構

```
┌──────────────────────────────────────────────────────────────────┐
│                FastAPI App  (waifu/router/)                       │
│                                                                   │
│  GET /health   POST /chat   WS /ws   POST /webhook/discord  ...  │
│       └─────────────────────────────────────┘                    │
│                    APIRouter 組織 HTTP 端點                        │
└────────────────────────────┬─────────────────────────────────────┘
                             │  HTTP / WebSocket
┌────────────────────────────▼─────────────────────────────────────┐
│                    Gateway Adapters（可插拔）                      │
│                                                                   │
│  WebSocketAdapter  DiscordAdapter  TelegramAdapter  HTTPAdapter   │
│  (掛在 /ws)        (discord.py)    (python-telegram) (掛在 /chat) │
└──────────┬─────────────┬──────────────┬─────────────┬────────────┘
           └─────────────┴──────────────┴─────────────┘
                                │  IncomingRequest
                       ┌────────▼────────┐
                       │   GatewayCore   │
                       │  waifu/gateway/ │
                       │                 │
                       │  SessionManager │  session_id 跨 adapter 共享
                       │  LaneQueue      │  per-channel 串行
                       └────────┬────────┘
                                │
                       ┌────────▼────────┐
                       │  HookPipeline   │  pre hooks
                       │  waifu/hook/    │
                       └────────┬────────┘
                                │
                       ┌────────▼────────┐
                       │  PluginManager  │  工具動態載入/注入
                       │  waifu/plugin/  │
                       └────────┬────────┘
                                │  AgentInput
                       ┌────────▼────────┐
                       │  waifu/agent/   │  Context Builder + Shuvi 包裝
                       └────────┬────────┘
                                │
                       ┌────────▼────────┐
                       │  Shuvi Agent    │  tool-calling loop（不動）
                       │  shuvi/         │
                       └────────┬────────┘
                                │
                       ┌────────▼────────┐
                       │  HookPipeline   │  post hooks
                       │  waifu/hook/    │
                       └────────┬────────┘
                                │  OutgoingResponse
                       原始 Adapter.send()
                       ├── WS: stream chunks + Live2D events
                       ├── Discord: channel.send(content)
                       └── Telegram: message.reply_text(content)
```

---

## 各模組職責

### `waifu/gateway/`

Gateway 是整個系統的**唯一入口**，負責：

1. **Adapter 管理**：掛載多個 `BaseGatewayAdapter`（WS、Discord、Telegram、HTTP）
2. **Conversation 管理**：所有對話均有歷史，依模式決定範圍與用戶結構
3. **Lane Queue**：每個 `conversation_id` 一條 asyncio.Queue，確保同一對話空間串行處理

**三種對話模式**

```
┌──────────┬────────────────────────────────┬────────────────────────────┬───────────────────┐
│ 模式      │ 對話歷史範圍                   │ 適用來源                   │ 觸發條件          │
├──────────┼────────────────────────────────┼────────────────────────────┼───────────────────┤
│ SESSION  │ per session（可跨重連恢復）     │ WebSocket / Live2D 客戶端  │ 任何訊息          │
│ DIRECT   │ per user（跨次連線持久化）      │ Discord DM / Telegram 私聊 │ 任何訊息          │
│ GROUP    │ per room（多用戶共用）          │ Discord 頻道 / TG 群組     │ @mention / 指令   │
└──────────┴────────────────────────────────┴────────────────────────────┴───────────────────┘
```

**各模式行為差異**

| 行為                 | SESSION                    | DIRECT                  | GROUP                           |
| -------------------- | -------------------------- | ----------------------- | ------------------------------- |
| `conversation_id` 鍵 | session token              | `{source}:dm:{user_id}` | `{source}:room:{room_id}`       |
| 歷史作者標記          | 不需要                     | 不需要                  | 需要（`[UserA]: ...`）          |
| 多人同時發訊         | 不存在                     | 不存在                  | Lane 串行排隊                   |
| 重連歷史恢復         | ✅ via session token        | ✅ 自動（user 為鍵）     | ✅ 自動（room 為鍵）             |

**統一訊息格式**

```python
class ConversationMode(str, Enum):
    session = "session"   # WebSocket 1:1，以 session token 恢復歷史
    direct  = "direct"    # 通訊軟體 1:1，以 user_id 持久化
    group   = "group"     # 通訊軟體群組，以 room_id 持久化，多用戶

class Sender(BaseModel):
    user_id: str          # 全域唯一，e.g. "discord:user:123456"
    display_name: str     # 群組歷史標記用

class IncomingRequest(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    request_id: str                       # uuid，自動生成
    conversation_id: str                  # Lane / 歷史記憶的鍵
    mode: ConversationMode
    sender: Sender                        # 發送者身份
    source: str                           # adapter 名稱（"websocket" / "discord" / ...）
    content: str
    attachments: List[Attachment] = []
    metadata: Dict[str, Any] = {}         # 平台特定（guild_id, chat_id...）
    reply_fn: Callable

class OutgoingResponse(BaseModel):
    request_id: str
    conversation_id: str
    source: str
    content: str
    chunks: List[str] = []
    trace: Optional[ExecutionTrace] = None
    events: List[Dict] = []               # Live2D emotion/action
    reply_fn: Callable
```

**各 Adapter 的 conversation_id 映射**

```python
# WebSocketAdapter → SESSION
conversation_id = f"ws:{session_token}"       # 重連可恢復
sender = Sender(user_id=f"ws:{session_token}", display_name="User")

# DiscordAdapter → DM → DIRECT
conversation_id = f"discord:dm:{user.id}"
sender = Sender(user_id=f"discord:user:{user.id}", display_name=user.display_name)

# DiscordAdapter → 伺服器頻道 → GROUP（僅 @mention 時 dispatch）
conversation_id = f"discord:channel:{channel.id}"
sender = Sender(user_id=f"discord:user:{user.id}", display_name=user.display_name)

# TelegramAdapter → 私聊 → DIRECT
conversation_id = f"telegram:chat:{chat.id}"
sender = Sender(user_id=f"telegram:user:{user.id}", display_name=user.full_name)

# TelegramAdapter → 群組 → GROUP（僅 @mention 或 /shuvi 時 dispatch）
conversation_id = f"telegram:group:{chat.id}"
sender = Sender(user_id=f"telegram:user:{user.id}", display_name=user.full_name)
```

**GROUP 模式：ContextBuilder 組裝歷史時加入作者標記**

```python
# GROUP 模式歷史訊息
[
    {"role": "user", "content": "[Alice]: 你好"},
    {"role": "assistant", "content": "你好！有什麼可以幫你的？"},
    {"role": "user", "content": "[Bob]: 幫我找一首歌"},
]

# DIRECT / SESSION 模式歷史訊息（不需前綴）
[
    {"role": "user", "content": "你好"},
    {"role": "assistant", "content": "你好！有什麼可以幫你的？"},
]
```

**GROUP 觸發條件（Adapter 層過濾，不進入 GatewayCore）**

```python
# DiscordAdapter：@mention 或回覆 bot 訊息才 dispatch
if bot.user in message.mentions or (message.reference and ...):
    await core.dispatch(build_request(message, mode=GROUP))

# TelegramAdapter：@mention 或 /shuvi 指令才 dispatch
if f"@{bot_username}" in text or text.startswith("/shuvi"):
    await core.dispatch(build_request(update, mode=GROUP))
```

**內建 Adapter 比較**

| Adapter            | 傳輸                | Streaming        | 支援模式          | Live2D Events |
| ------------------ | ------------------- | ---------------- | ----------------- | ------------- |
| `WebSocketAdapter` | FastAPI WS          | ✅ chunk by chunk | SESSION           | ✅             |
| `DiscordAdapter`   | discord.py          | edit 模擬        | DIRECT / GROUP    | ❌             |
| `TelegramAdapter`  | python-telegram-bot | edit 模擬        | DIRECT / GROUP    | ❌             |
| `HTTPAdapter`      | FastAPI REST        | SSE streaming    | SESSION / DIRECT  | ❌             |

**WebSocket 訊息協議**

```jsonc
// Client → Server
{ "type": "chat", "conversation_id": "main", "request_id": "uuid", "content": "你好！" }

// Server → Client (chunk)
{ "type": "chunk", "request_id": "uuid", "content": "你" }

// Server → Client (done)
{ "type": "done", "request_id": "uuid", "usage": {...}, "trace": {...} }

// Server → Client (Live2D event)
{ "type": "event", "event": "emotion", "data": { "emotion": "happy" } }
```

---

### `waifu/router/`

FastAPI **APIRouter**，組織所有 HTTP 端點。各功能模組在此掛載路由，最終 include 到主 FastAPI app。

```python
# waifu/router/ws.py — WebSocket 端點
router = APIRouter()

@router.websocket("/ws")
async def ws_endpoint(websocket: WebSocket, waifu: Waifu = Depends(get_waifu)):
    await waifu.gateway.ws_adapter.handle(websocket)

# waifu/router/chat.py — REST 端點
router = APIRouter(prefix="/chat")

@router.post("/")
async def chat(body: ChatRequest, waifu: Waifu = Depends(get_waifu)) -> ChatResponse:
    return await waifu.gateway.http_adapter.handle(body)

# waifu/router/health.py
router = APIRouter()

@router.get("/health")
async def health(): return {"status": "ok"}

# waifu/router/plugin.py — 插件管理 API（可選）
router = APIRouter(prefix="/plugins")

@router.get("/")
async def list_plugins(waifu: Waifu = Depends(get_waifu)):
    return waifu.plugin_manager.list()

@router.post("/{name}/enable")
async def enable_plugin(name: str, waifu: Waifu = Depends(get_waifu)): ...

@router.delete("/{name}")
async def unload_plugin(name: str, waifu: Waifu = Depends(get_waifu)): ...

# waifu/router/__init__.py — 統一掛載
def include_routers(app: FastAPI) -> None:
    app.include_router(ws.router)
    app.include_router(chat.router)
    app.include_router(health.router)
    app.include_router(plugin.router)
```

---

### `waifu/hook/`

Hook 在 Agent 執行前後注入邏輯，完全可插拔。

```python
class BaseHook(ABC):
    name: str
    priority: int = 0  # 數字越小越先執行

    async def pre(self, ctx: HookContext) -> HookContext: ...
    async def post(self, ctx: HookContext) -> HookContext: ...

class HookContext(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    request: IncomingRequest
    session: Session
    messages: List[Dict[str, Any]]  # 可被 hook 修改
    metadata: Dict[str, Any] = {}
    response: Optional[str] = None  # post hook 時有值
    trace: Optional[ExecutionTrace] = None
    events: List[Dict] = []         # 副作用（EmotionHook 寫入）
    abort: bool = False             # True 則跳過 Agent
```

---

### `waifu/plugin/`  +  `waifu-sdk/`

**設計原則**：Base classes 定義在 `waifu-sdk`，`waifu` 實作 `PluginManager`，第三方只需依賴輕量的 `waifu-sdk`。

```
waifu-sdk/              ← 插件作者安裝的套件
  定義 Protocol/ABC：
    BasePlugin, PluginContext
    BaseGatewayAdapter
    BaseHook, HookContext
    BaseMCPAdapter
    IncomingRequest, OutgoingResponse
    Tool (re-export from hai)

waifu/plugin/           ← 核心實作，僅服務端需要
  PluginManager         載入/啟用/停用/卸載插件
  PluginContext impl    注入 hook/tool/mcp registry
  內建插件              MCPPlugin, ToolPlugin, HookPlugin
```

**waifu-sdk 套件結構**

```
waifu-sdk/waifu-sdk/
├── __init__.py          # 公開 API
├── plugin.py            # BasePlugin, PluginContext (Protocol)
├── adapter.py           # BaseGatewayAdapter
├── hook.py              # BaseHook, HookContext
├── mcp.py               # BaseMCPAdapter
└── types.py             # IncomingRequest, OutgoingResponse, Attachment
```

```python
# waifu-sdk/waifu-sdk/plugin.py

class PluginContext(Protocol):
    """插件載入時取得的系統資源存取點（waifu 實作，sdk 定義介面）"""
    config: Dict[str, Any]

    def register_hook(self, hook: "BaseHook") -> None: ...
    def register_tool(self, tool: Tool) -> None: ...
    def register_mcp(self, name: str, adapter: "BaseMCPAdapter") -> None: ...

class BasePlugin(ABC):
    name: str
    version: str = "0.1.0"
    description: str = ""

    @abstractmethod
    async def on_load(self, ctx: PluginContext) -> None:
        """初始化：連線外部服務、注冊 Hook/Tool/MCP"""
        ...

    async def on_enable(self) -> None: ...
    async def on_disable(self) -> None: ...
    async def on_unload(self) -> None: ...
```

**PluginManager（waifu/plugin/ 實作）**

```python
class PluginState(str, Enum):
    loading  = "loading"
    enabled  = "enabled"
    disabled = "disabled"
    error    = "error"

class PluginManager:
    def __init__(self, hook_registry, tool_registry, mcp_registry): ...

    async def load(self, plugin: BasePlugin, config: Dict = {}) -> None:
        """呼叫 on_load()，建立 PluginContext 並注入資源"""
        ctx = _PluginContextImpl(hook_registry, tool_registry, mcp_registry, config)
        await plugin.on_load(ctx)
        self._plugins[plugin.name] = (plugin, PluginState.enabled)

    async def unload(self, name: str) -> None:
        plugin, _ = self._plugins[name]
        await plugin.on_disable()
        await plugin.on_unload()
        del self._plugins[name]

    async def enable(self, name: str) -> None: ...
    async def disable(self, name: str) -> None: ...

    def list(self) -> List[Dict]:
        return [{"name": n, "state": s, "version": p.version}
                for n, (p, s) in self._plugins.items()]
```

**第三方插件撰寫（只依賴 waifu-sdk）**

```python
# pip install waifu-sdk
from waifu_sdk import BasePlugin, PluginContext, BaseMCPAdapter

class MyMCPPlugin(BasePlugin):
    name = "my-mcp"
    version = "1.0.0"

    def __init__(self, server_url: str):
        self._url = server_url

    async def on_load(self, ctx: PluginContext) -> None:
        adapter = MyMCPAdapter(self._url)   # 實作 BaseMCPAdapter
        await adapter.connect()
        ctx.register_mcp("my-mcp", adapter)

    async def on_unload(self) -> None:
        await self._adapter.disconnect()
```

**內建插件（waifu/plugin/builtin/）**

```python
class MCPPlugin(BasePlugin):
    """將任意 BaseMCPAdapter 包裝成插件"""
    def __init__(self, name: str, adapter: BaseMCPAdapter): ...

class ToolPlugin(BasePlugin):
    """將一組本地 Tool 包裝成插件"""
    def __init__(self, name: str, tools: List[Tool]): ...

class HookPlugin(BasePlugin):
    """將 Hook 包裝成插件（方便動態啟停）"""
    def __init__(self, hook: BaseHook): ...
```

**組裝範例**

```python
# 載入內建插件
await waifu.load_plugin(MCPPlugin("filesystem", StdioMCPAdapter([...])))
await waifu.load_plugin(ToolPlugin("search", [WebSearchTool()]))
await waifu.load_plugin(HookPlugin(RateLimitHook(max_rpm=60)), config={})

# 載入第三方插件
from my_company_plugin import SlackNotifyPlugin
await waifu.load_plugin(SlackNotifyPlugin(), config={"webhook_url": "..."})

# 動態管理（透過 REST API 或程式碼）
await waifu.plugin_manager.disable("filesystem")
await waifu.plugin_manager.enable("filesystem")
await waifu.plugin_manager.unload("search")
```

---

### `waifu/mcp/`

MCP 模組橋接外部 MCP Server，並透過 `MCPPlugin` 注入 PluginRegistry。

```python
class BaseMCPAdapter(ABC):
    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def list_tools(self) -> List[Tool]: ...
    async def call_tool(self, name: str, args: Dict) -> str: ...

# 實作
class StdioMCPAdapter(BaseMCPAdapter):
    def __init__(self, cmd: List[str]): ...  # ["npx", "mcp-server-filesystem", "."]

class SSEMCPAdapter(BaseMCPAdapter):
    def __init__(self, url: str): ...        # http://localhost:8080/sse
```

---

### `waifu/agent/`

Agent 模組是 **ContextBuilder + Shuvi Agent 的包裝層**，組裝完整 input 後委派給 `shuvi.Agent`。

```python
class AgentInput(BaseModel):
    system_prompt: str
    messages: List[Dict[str, Any]]
    tools: List[Tool]

class ContextBuilder:
    """
    組裝：
    1. system_prompt（角色設定 + 當前時間 + 使用者資訊）
    2. messages（歷史 + 當前輸入）
    3. tools（PluginRegistry.get_all_tools()）
    """
    async def build(self, ctx: HookContext, plugins: PluginRegistry) -> AgentInput: ...

class AgentRunner:
    """包裝 shuvi.Agent，注入 streaming callback"""
    async def run(self, ctx: HookContext, agent_input: AgentInput) -> AgentResult:
        agent = Agent(AgentConfig(
            provider=self._provider,
            system_prompt=agent_input.system_prompt,
            tools=agent_input.tools,
            callbacks=AgentCallbacks(
                assistant_message=lambda msg: ctx.request.reply_fn(chunk=msg),
            ),
        ))
        return await agent.run(agent_input.messages)
```

---

### `waifu/config/`

```python
class GatewayConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8765
    session_ttl: int = 3600
    lane_max_queue: int = 10

class ContextConfig(BaseModel):
    system_prompt_template: str
    max_history_messages: int = 20
    history_strategy: Literal["sliding", "summary", "full"] = "sliding"

class ProviderConfig(BaseModel):
    api_key: str
    base_url: str
    model: str
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    stream: bool = True

class WaifuConfig(BaseModel):
    gateway: GatewayConfig = GatewayConfig()
    context: ContextConfig
    provider: ProviderConfig
```

---

### `waifu/cli/`

提供 `waifu` CLI 指令：

```bash
waifu start                    # 啟動服務
waifu start --config config.toml
```

---

### `waifu/waifu.py`（主類）

```python
class Waifu:
    def __init__(self, config: WaifuConfig):
        self.core = GatewayCore(config.gateway)
        self.router = DefaultRouter()
        self.hook_registry = HookRegistry()
        self.plugin_registry = PluginRegistry()
        self._provider = build_provider(config.provider)
        self._context_builder = ContextBuilder(config.context)

    # Gateway Adapter（可插拔）
    def mount(self, adapter: BaseGatewayAdapter) -> "Waifu":
        self.core.mount(adapter)
        return self

    # Router
    def route(self, router: BaseRouter) -> "Waifu":
        self.router = router
        return self

    # Hook（可插拔）
    def use(self, hook: BaseHook) -> "Waifu":
        self.hook_registry.register(hook)
        return self

    # Plugin / MCP / Tool（可插拔）
    async def plugin(self, p: BasePlugin) -> "Waifu":
        await self.plugin_registry.mount(p)
        return self

    async def start(self) -> None:
        await self.core.start()
```

**組裝範例**

```python
from fastapi import FastAPI
from waifu import Waifu, WaifuConfig
from waifu.gateway.adapters import WebSocketAdapter, DiscordAdapter, TelegramAdapter
from waifu.hook.builtin import RateLimitHook, MemoryHook, EmotionHook
from waifu.mcp import StdioMCPAdapter, MCPPlugin
from waifu.plugin import ToolPlugin
from my_tools import WebSearchTool

app = FastAPI()

ws = WebSocketAdapter()
ws.mount(app, path="/ws")

waifu = (
    Waifu(config)
    .mount(ws)
    .mount(DiscordAdapter(token=DISCORD_TOKEN))
    .mount(TelegramAdapter(token=TG_TOKEN))
    .use(RateLimitHook(max_rpm=60))
    .use(MemoryHook(store=redis))
    .use(EmotionHook())
)

await waifu.plugin(MCPPlugin(StdioMCPAdapter(["npx", "mcp-server-filesystem"])))
await waifu.plugin(ToolPlugin([WebSearchTool()]))
await waifu.start()
```

---

## 完整請求生命週期

```
來源差異（Adapter 層處理，統一轉為 IncomingRequest）：

  WS (SESSION)
    → ws message
    → IncomingRequest(mode=SESSION, conversation_id="ws:{token}", sender=...)

  Discord DM (DIRECT)
    → on_message() [私訊]
    → IncomingRequest(mode=DIRECT, conversation_id="discord:dm:{uid}", sender=...)

  Discord 頻道 (GROUP)
    → on_message() [@mention 過濾]
    → IncomingRequest(mode=GROUP, conversation_id="discord:channel:{cid}", sender=...)

  Telegram 私聊 (DIRECT)
    → on_message() [私訊]
    → IncomingRequest(mode=DIRECT, conversation_id="telegram:chat:{cid}", sender=...)

  Telegram 群組 (GROUP)
    → on_message() [@mention / /shuvi 過濾]
    → IncomingRequest(mode=GROUP, conversation_id="telegram:group:{gid}", sender=...)

共同流程：
  GatewayCore.dispatch(req)
    → Lane[conversation_id].enqueue(req)     ← 同一對話空間串行排隊

  Lane worker:
    → HookPipeline.pre(ctx)
    → HookPipeline.pre(ctx)
         RateLimitHook  → 限流
         MemoryHook     → 注入歷史 messages
         ModerationHook → 內容審核
    → ContextBuilder.build(ctx, plugin_registry)
         system_prompt + tools
         + messages（GROUP 模式加 [DisplayName]: 前綴）
    → AgentRunner.run(ctx, agent_input)
         shuvi.Agent inner loop（tool calling）
         ├─ WS:              stream chunks 即時回傳
         └─ Discord/TG:      edit 模擬 streaming（或累積後送出）
    → HookPipeline.post(ctx)
         EmotionHook → 解析情緒 → ctx.events
         MemoryHook  → 儲存對話歷史（key: conversation_id）
         LoggingHook → 記錄 trace
    → adapter.send(OutgoingResponse)
         WS (SESSION)         → chunks + events（Live2D）
         Discord DM (DIRECT)  → channel.send(content)
         Discord 頻道 (GROUP)  → channel.send(content)（可 @mention 發送者）
         Telegram (DIRECT)    → message.reply_text(content)
         Telegram 群組 (GROUP) → message.reply_text(content)
```


---

## waifu-sdk

`waifu-sdk` 是**所有擴展點的 Protocol 定義套件**，不包含任何業務邏輯。第三方開發者只需安裝輕量的 `waifu-sdk`，不需要安裝完整的 `waifu` server。

```
waifu-sdk 依賴：pydantic（僅用於型別定義）
waifu       依賴：waifu-sdk + fastapi + discord.py + ...
```

**公開 API**

```python
# waifu-sdk/waifu-sdk/__init__.py
from .plugin import BasePlugin, PluginContext
from .adapter import BaseGatewayAdapter
from .hook import BaseHook, HookContext
from .mcp import BaseMCPAdapter
from .types import IncomingRequest, OutgoingResponse, Attachment

__all__ = [
    "BasePlugin", "PluginContext",
    "BaseGatewayAdapter",
    "BaseHook", "HookContext",
    "BaseMCPAdapter",
    "IncomingRequest", "OutgoingResponse", "Attachment",
]
```

**第三方擴展情境**

```python
# 自定義 Gateway Adapter（例如 Slack）
from waifu_sdk import BaseGatewayAdapter, IncomingRequest, OutgoingResponse

class SlackAdapter(BaseGatewayAdapter):
    name = "slack"

    async def start(self, core) -> None:
        # 監聽 Slack Events API → IncomingRequest → core.dispatch()
        ...

    async def send(self, response: OutgoingResponse) -> None:
        # 回傳到 Slack channel（bolt SDK）
        ...

# 自定義 Hook
from waifu_sdk import BaseHook, HookContext

class TranslateHook(BaseHook):
    name = "translate"

    async def pre(self, ctx: HookContext) -> HookContext:
        ctx.messages[-1]["content"] = await translate_to_en(ctx.messages[-1]["content"])
        return ctx

    async def post(self, ctx: HookContext) -> HookContext:
        ctx.response = await translate_to_zh(ctx.response)
        return ctx

# 自定義 MCP Adapter
from waifu_sdk import BaseMCPAdapter

class MySSEMCPAdapter(BaseMCPAdapter):
    async def connect(self) -> None: ...
    async def list_tools(self) -> List[Tool]: ...
    async def call_tool(self, name: str, args: Dict) -> str: ...
```

---

## 套件依賴關係

```
waifu-sdk                          ← Protocol/ABC 定義，無業務邏輯
  pydantic

waifu                              ← Server 實作
  waifu-sdk                        ← 繼承所有 base class
  fastapi
  hai                              ← LLM providers, tools, loaders
  shuvi                            ← Agent loop
  discord.py        (optional)
  python-telegram-bot (optional)

第三方 Plugin 套件                  ← 只需依賴 waifu-sdk
  waifu-sdk
```

## 模組內部依賴

```
Waifu  (waifu/waifu.py)
├── GatewayCore          (waifu/gateway/)
│     ├── SessionManager
│     ├── LaneQueue
│     └── Adapters（可插拔，實作 waifu-sdk.BaseGatewayAdapter）
│           ├── WebSocketAdapter   FastAPI WS
│           ├── DiscordAdapter     discord.py
│           ├── TelegramAdapter    python-telegram-bot
│           └── HTTPAdapter        FastAPI REST
│
├── APIRouter            (waifu/router/)   FastAPI 路由組織
│     ├── /ws            → WebSocketAdapter
│     ├── /chat          → HTTPAdapter
│     ├── /health
│     └── /plugins       → PluginManager REST API
│
├── HookRegistry         (waifu/hook/)     pre/post 鏈
│     └── HookPipeline
│
├── PluginManager        (waifu/plugin/)   插件生命週期
│     ├── MCPPlugin     → waifu/mcp/ → hai.tool.Tool
│     ├── ToolPlugin    → hai.tool.Tool
│     └── HookPlugin    → HookRegistry
│
├── AgentRunner          (waifu/agent/)
│     ├── ContextBuilder
│     └── shuvi.Agent
│           └── hai.providers.ProviderText
│
└── WaifuConfig          (waifu/config/)
```

---

## 實作優先順序

**Phase 1 — 骨架**
- `waifu/gateway/` — GatewayCore + BaseGatewayAdapter + WebSocketAdapter + Session + Lane
- `waifu/types.py` — IncomingRequest, OutgoingResponse
- `waifu/agent/` — ContextBuilder + AgentRunner
- `waifu/waifu.py` — Waifu 主類
- `waifu/config/` — WaifuConfig

**Phase 2 — 插拔模組**
- `waifu/hook/` — BaseHook + HookRegistry + HookPipeline + 內建 hook
- `waifu/plugin/` — BasePlugin + PluginRegistry + ToolPlugin
- `waifu/router/` — BaseRouter + DefaultRouter

**Phase 3 — 外部 Adapter**
- `waifu/gateway/adapters/discord.py`
- `waifu/gateway/adapters/telegram.py`
- `waifu/gateway/adapters/http.py`

**Phase 4 — MCP**
- `waifu/mcp/` — BaseMCPAdapter + StdioMCPAdapter + SSEMCPAdapter + MCPPlugin

**Phase 5 — 前端**
- Live2D 客戶端（WebSocket + streaming UI + 情緒事件）

**Phase 6 — CLI & SDK**
- `waifu/cli/` — `waifu start` / `waifu dev`
- `waifu-sdk/` — 對外 API re-export
