# Waifu 專案論文技術整理

## 1. 專案基本資料

### 1.1 專案定位

Waifu 是一個以 Python 為核心的 AI Assistant 後端系統，目標是提供可擴充、可持久化、可多通道接入的角色型智慧助理執行環境。它不只是單純的聊天 API，而是一個整合了：

- 多種入口通道的 Gateway
- Agent 執行循環
- 插件系統
- 工具呼叫機制
- MCP 伺服器整合
- 對話與角色持久化
- WebSocket / HTTP / Discord / Telegram 等互動模式

的完整後端平台。

### 1.2 倉庫內主要模組

本倉庫是 uv workspace monorepo，核心包含三個正式套件與兩個內嵌基礎依賴層：

| 模組 | 性質 | 職責 |
| --- | --- | --- |
| waifu | 主後端套件 | 實際提供伺服器、路由、Gateway、插件、儲存、Agent 封裝 |
| waifu_sdk | SDK | 對第三方開發者重匯出 waifu_types，降低依賴耦合 |
| waifu_types | 型別與抽象層 | 定義共享資料模型、ABC、Protocol、訊息型別 |
| hai | 基礎 AI 能力層 | 類似 LangChain 的底層框架，處理 provider、tool、loader、flow、document 等 |
| shuvi | Agent 執行循環層 | 負責 tool-calling loop、驗證迴圈、追蹤資訊 |

### 1.3 前端資訊

- 前端專案為 yori-ai
- yori-ai 不在此倉庫內
- 因此本文件只描述後端與底層 AI 執行框架
- 若論文需要完整系統架構，前端應視為外部客戶端或上層應用層

---

## 2. 技術棧總覽

### 2.1 語言與執行環境

- Python >= 3.10
- uv workspace 作為 monorepo 與套件建置管理
- uv_build 作為 build backend

### 2.2 後端框架與核心依賴

- FastAPI：HTTP 與 WebSocket 服務框架
- Uvicorn：ASGI server
- Pydantic v2：設定模型、訊息模型與資料驗證
- Peewee：SQLite ORM
- Textual：TUI 介面
- tomli-w：設定檔寫回
- httpx：HTTP client
- discord.py：Discord adapter
- python-telegram-bot：Telegram adapter

### 2.3 AI 執行相關依賴

- hai：Provider、Tool、Flow、文件載入與處理
- shuvi：Agent 主循環與 tool-calling orchestration

---

## 3. Monorepo 與分層設計

### 3.1 waifu_types：型別與協定層

waifu_types 是整個生態系的介面真實來源。它只依賴 pydantic，目的在於讓所有外部擴充點都能依賴穩定的抽象層，而不是直接耦合 waifu 主實作。

其匯出的核心內容包括：

- 訊息型別：UserMessage、AssistantMessage、ToolMessage、SystemMessage、GenericMessage
- 工具呼叫型別：ToolCall、ToolCallFunction
- 請求回應型別：IncomingRequest、OutgoingResponse、Attachment、Sender
- 抽象介面：BaseGatewayAdapter、BaseHook、BaseMCPAdapter、BasePlugin
- Protocol：ConversationService、SessionService、VoiceServiceProtocol
- Session / Trace 基底：BaseSession、BaseExecutionTrace

這種設計使得插件作者、Adapter 作者與外部 SDK 使用者都可只依賴型別層。

### 3.2 waifu_sdk：對外 SDK 層

waifu_sdk 本身極薄，主要只是重匯出 waifu_types。它的意義不在於邏輯，而在於提供對外穩定名稱與安裝入口，讓第三方擴充不需要直接依賴內部模組路徑。

可視為：

- 第三方插件開發者的官方依賴入口
- 穩定 API 表面層
- 主系統與生態外掛之間的去耦合包裝

### 3.3 waifu：應用與平台層

waifu 是實際執行系統，負責：

- 啟動 FastAPI 應用
- 組裝所有元件
- 管理 Gateway、Hook、Plugin、Store、Service
- 將 shuvi Agent 與 hai provider/tool 接到應用流程中

### 3.4 hai：AI 基礎能力層

hai 可視為類似 LangChain 的底層框架，但本專案是以自有實作方式提供下列能力：

- ProviderText：模型供應者呼叫封裝
- ProviderSTT / ProviderTTS：語音辨識與合成供應者封裝
- Tool：OpenAI function-calling 風格工具封裝
- Flow：節點式 pipeline 執行器
- BaseNode：可鏈接節點抽象
- Document：文件物件
- loader：文字、CSV、JSON、Markdown、Web 載入
- processor / preprocessor：切分、清理、metadata 擷取
- vectorstores / graphstores：向量與圖儲存基礎能力

從架構上看，hai 是基礎能力庫，不直接代表 Waifu 的使用者體驗，而是提供 Waifu 與 Shuvi 所需的 AI 基礎模組。

### 3.5 shuvi：Agent 執行循環層

shuvi 負責真正的 agent loop，不是單純的一次模型呼叫。其重要職責包括：

- 內層迴圈：模型回覆、工具呼叫、工具結果回注、再推進下一輪
- 外層驗證：若 verify function 不通過，可要求 agent 自我修正
- 執行追蹤：統計 token、tool calls、迭代次數、耗時
- 可中斷與狀態管理：LoopState、transition、turn_count

因此，在論文中可以把 Shuvi 定義為：

「位於 LLM provider 與應用層之間的 agent orchestration runtime」。

---

## 4. 核心架構概念

### 4.1 組裝根：Waifu 類別

waifu/waifu.py 中的 Waifu 類別是整個系統的 Composition Root。它負責建立與注入所有依賴，而不是承載單一業務功能。

初始化流程包含：

1. 解析 AppPaths
2. 初始化 SQLite Database
3. 初始化 ConversationStore
4. 初始化 CharacterManager
5. 根據設定建立 ProviderText
6. 根據語音設定建立 VoiceService
7. 建立 HookRegistry 與 HookPipeline
8. 建立 ContextBuilder 與 AgentRunner
9. 建立 GatewayCore
10. 建立 PluginRegistry、NodeManager、PluginManager、PluginLoader
11. 建立 Repository 與 Service 層
12. 設定 Gateway dispatch handler 指向 Waifu._dispatch

這代表 Waifu 本身是平台組裝者，而非單一功能模組。

### 4.2 整體請求生命週期

系統請求生命週期如下：

1. 外部來源送入訊息
2. Adapter 將平台資料轉成統一的 IncomingRequest
3. GatewayCore 依 conversation_id 導入對應 Lane queue
4. HookPipeline 執行 pre hooks
5. ContextBuilder 建立系統提示與上下文
6. AgentRunner 包裝 shuvi.Agent 執行
7. Shuvi 進行模型呼叫與工具循環
8. HookPipeline 執行 post hooks
9. 回傳 OutgoingResponse
10. Adapter 將結果發送到原平台

這種設計的關鍵價值是：

- 多平台入口統一
- 同一對話上下文能持久化與排隊
- Agent 與 UI/平台傳輸解耦
- 插件與工具可在不改核心流程下插入

---

## 5. Gateway 與多通道接入

### 5.1 GatewayCore 的角色

GatewayCore 是系統唯一入口，負責三件事：

- Adapter 管理
- Session 管理
- Lane 串行排隊

它不直接依賴 Agent 或 Hook 實作，而是透過注入 dispatch handler 完成解耦。

### 5.2 Lane 模型

每個 conversation_id 對應一條 Lane queue。這表示：

- 同一對話空間內的請求必須串行處理
- 避免多個並行請求污染同一對話上下文
- 群組場景下可避免上下文交錯

這是 Waifu 專案中很重要的並發控制策略。

### 5.3 Session 模型與對話模式

專案支援三種 ConversationMode：

| 模式 | 典型來源 | 歷史範圍 | 特性 |
| --- | --- | --- | --- |
| SESSION | WebSocket | 每個 session token | 適合前端即時對話 |
| DIRECT | Discord DM / Telegram 私聊 | 每個 user | 適合個人長期記憶 |
| GROUP | Discord 頻道 / Telegram 群組 | 每個 room/channel | 多人共享場域 |

GROUP 模式下，ContextBuilder 會對使用者內容加上顯示名稱前綴，例如 [Alice]: 你好，以保留多用戶上下文辨識能力。

### 5.4 支援的 Adapter

目前設計與實作可對應下列入口：

- WebSocketAdapter
- HTTPAdapter
- DiscordAdapter
- TelegramAdapter
- WaifuNodeAdapter

其中：

- WebSocket 適合前端即時互動與 chunk streaming
- HTTP 提供 SSE 備援路徑
- Discord / Telegram 負責外部聊天平台整合
- WaifuNodeAdapter 用於本機節點控制能力

---

## 6. Agent 執行模型

### 6.1 ContextBuilder

ContextBuilder 的主要責任是把 HookContext 轉成 Shuvi 可用的 ContextManager 與 system prompt。其特點：

- 支援 soul_content 與 system_prompt_template 兩種系統提示來源
- 會把角色關係資料拼入 system prompt
- 可附帶目前對話者資訊與當前時間
- 會將文字與圖片附件轉為 multimodal message parts

### 6.2 Context Budget 機制

目前實作中已具備粗估 token 的上下文控制：

- 使用 chars / 4 粗估 token 數
- 設定 context_token_budget 與 compact_threshold
- 若超過閾值，會從較舊訊息開始裁切

這不是完整語義摘要壓縮，而是 budget-based trimming。對論文而言，可描述為：

- 已有基礎上下文治理
- 尚未完成語義摘要式 context compaction

### 6.3 AgentRunner

AgentRunner 是 waifu 對 shuvi.Agent 的應用層包裝。其提供：

- per-conversation QueryState
- turn_count、failure count、last outcome 等狀態追蹤
- streaming chunk 回呼轉接到 reply_fn
- 最多一次 retry 的錯誤恢復
- 將 token usage 與 inner iteration 結果回寫至狀態

### 6.4 Shuvi Agent 迴圈

shuvi.Agent 的執行模式具有以下結構：

1. 先準備上下文訊息
2. 呼叫 ProviderText 取得回覆
3. 若模型產生 tool_calls，逐一執行工具
4. 把 tool result 當作 ToolMessage 回注到訊息序列
5. 持續迴圈直到無工具呼叫
6. 若設定 verify function，進入外層驗證與可能的修正迴圈

其追蹤資訊包括：

- start_time / end_time
- token_usage
- inner_iterations
- outer_retries
- outcome
- tool_calls trace
- verification records

因此，Shuvi 不是一般聊天封裝，而是具備可追蹤、可驗證的 Agent Runtime。

---

## 7. 工具系統與 Tool Calling

### 7.1 hai.tool.Tool

hai 的 Tool 類別將 Python callable 包裝成 OpenAI function-calling 相容的工具格式。其核心能力：

- 以 JSON Schema 描述參數
- 轉換成 OpenAI tools payload
- 自動解析 arguments JSON
- 支援 sync / async function
- 工具失敗時回傳錯誤字串，而不是直接中止整個對話流程

這種錯誤策略可降低 agent loop 因單次工具失敗而整體崩潰的機率。

### 7.2 內建工具

Waifu 目前在啟動時會預先註冊：

- read_tool
- write_tool
- shell_tool
- webfetch_tool

它們透過 PluginRegistry 統一暴露給 Agent。

### 7.3 工具系統的研究重點

可在論文中討論的技術點包括：

- 工具作為 LLM 能力擴展層
- 工具失敗不拋例外，而回傳結構化錯誤訊息
- Agent 如何把工具輸出重新注入推理鏈
- 高風險工具如 shell_tool 的安全治理仍屬未完全完成項

---

## 8. Plugin 與 MCP 架構

### 8.1 PluginRegistry

PluginRegistry 統一管理三類擴充：

- tools
- hooks
- mcp adapters

這讓插件系統可以在 on_load 時一次向平台註冊多種能力。

### 8.2 PluginManager

PluginManager 負責插件生命週期：

- load
- unload
- enable
- disable
- list

在 load 時，PluginManager 會建立 _PluginContextImpl，讓插件能拿到：

- config
- conversation store
- sessions service
- gateway
- voice service
- hook registry / plugin registry

這代表插件可以註冊工具，也可以動態掛載 Adapter。

### 8.3 Plugin Loader

根據 localdocs 與現有實作，插件支援從 plugins 資料夾掃描 metadata.json，並以 importlib 載入 entry class。

這種設計的特色是：

- 支援檔案系統安裝式插件
- 支援 metadata 驅動的 plugin 描述
- 能對接 UI 管理與 DB 持久化

### 8.4 MCP 整合

專案中的 MCP 層負責把外部工具服務整合進系統。支援兩類 Adapter：

- StdioMCPAdapter：透過 subprocess 與 JSON-RPC over stdin/stdout
- SSEMCPAdapter：透過 HTTP SSE 連線

這使 Waifu 不只支援本地工具，還能接外部 MCP server 生態。

---

## 9. 路由與 API 設計

### 9.1 路由組成

waifu/router/__init__.py 會依實際注入元件決定掛哪些 router。可確認的路由面向包括：

- health
- ws
- chat
- plugin
- mcp
- config
- character
- conversation
- tools
- session
- analytics
- status
- waifu_node

### 9.2 重要 API 類型

#### 基礎服務

- GET /health
- GET /status

#### 對話入口

- WS /ws
- POST /chat

#### 平台控制

- /plugins
- /mcp
- /config
- /characters
- /conversations
- /tools
- /sessions

### 9.3 API 的設計意義

這個後端不是只提供一條 chat API，而是明顯朝向「可管理的平台型後端」設計：

- 可透過 API 管理插件與 MCP
- 可透過 API 管理角色與對話
- 可透過 API 讀取系統狀態與 token analytics
- 可由前端 dashboard 直接控制後端行為

這是論文中很值得凸顯的架構特色。

---

## 10. 設定系統

### 10.1 WaifuConfig

WaifuConfig 目前包含：

- gateway：host、port、session_ttl、lane_max_queue
- context：system_prompt_template、max_history_messages、history_strategy、soul_content、context_token_budget、compact_threshold
- provider：api_key、base_url、model、temperature、max_tokens、stream
- voice：STT/TTS 與 lipsync 設定
- node：WaifuNodeConfig
- character：目前使用角色名稱

### 10.2 設定檔格式

CLI start 支援：

- TOML
- YAML / YML
- JSON

### 10.3 執行期設定熱更新

Waifu 啟動時會把初始 config seed 進資料庫，並透過 AppConfigService 與 config router 提供運行時讀寫能力。從專案設計脈絡看，這表示系統目標不是靜態 config-only，而是逐步走向 runtime configurable backend。

---

## 11. 資料儲存與持久化

### 11.1 儲存策略概覽

本專案採混合式持久化：

- SQLite：結構化資料
- Markdown / 檔案系統：對話、角色、記憶、插件檔案

### 11.2 AppPaths 路徑設計

AppPaths 對 Windows、macOS、Linux 提供平台化預設路徑。

Windows 下：

- Config dir：%APPDATA%/waifu/
- Data dir：%USERPROFILE%/Documents/waifu/

資料夾包含：

- conversations
- skills
- mcp
- soul
- characters
- memory
- plugins

這種做法將：

- 設定與資料分離
- 資料夾結構顯式化
- 使用者可直接以檔案系統管理部份內容

### 11.3 資料庫模型

目前可驗證的 Peewee models 包括：

- Conversation
- Message
- DailyTokenUsage
- CronJob
- CronRun
- PluginConfig
- MCPServer
- AppConfig
- Character
- Relationship

### 11.4 對話儲存

ConversationStore 提供：

- create / create_with_id / get / resolve
- list / count / delete / search
- compact
- add_message
- add_llm_message
- get_messages / get_messages_as_dicts
- export_markdown

其中 add_llm_message 很重要，因為它能保留：

- assistant message
- tool calls
- tool results

這表示系統的對話持久化不只是純文字 transcript，而是保留部分 agent 行為痕跡。

### 11.5 Token Analytics

DailyTokenUsage 表可依日期與 conversation_id 彙總：

- input_tokens
- output_tokens
- total_tokens

這使系統具備成本與使用量分析基礎。

---

## 12. 角色、記憶與語音

### 12.1 角色系統

角色相關資料包含：

- name
- soul_path
- avatar_path
- live2d_dir
- active

若設定 character，Waifu 會從 CharacterManager 載入 soul 內容並注入 context.soul_content。這代表角色人格實際上是透過 system prompt 層完成注入。

### 12.2 關係記憶

Relationship model 用來保存：

- character_id
- user_id
- display_name
- notes
- memory_path

它對應到角色與特定使用者的關係記錄，是角色長期互動個人化的重要基礎。

### 12.3 語音系統

VoiceService 透過 ProviderSTT 與 ProviderTTS 建立。特性包括：

- Whisper-compatible STT
- OpenAI TTS-compatible TTS
- lipsync_fps 設定

當 voice 啟用時，系統可經由 hook 與 adapter 把文字轉語音、輸出 lipsync 事件。

---

## 13. CLI 系統

### 13.1 CLI 的角色

waifu 並非只有 server mode，也有完整 CLI 控制面。主命令包括：

- init
- start
- run
- tui
- version
- config
- conversations / conversation
- skill
- mcp
- cron

### 13.2 CLI 的研究價值

CLI 表示 Waifu 的定位更接近平台工具，而不只是被動式 API server。這代表：

- 可作為本地 AI assistant daemon
- 可作為系統管理工具
- 可作為腳本與自動化入口

### 13.3 啟動模式

waifu start 可：

- 指定 config 路徑
- 覆蓋 host / port
- 指定自訂 FastAPI app
- 啟用 reload

這使系統具有開發模式與嵌入式模式兩種使用方式。

---

## 14. hai 的技術重點

### 14.1 ProviderText

ProviderText 是對 LLM API 的統一封裝，提供：

- model / api_key / base_url / temperature / max_tokens / stream 等配置
- 非串流請求
- 串流請求
- 指數退避 retry
- 工具呼叫 payload 注入

在非串流模式下，若模型回傳 tool_calls，ProviderText 也可以在 provider 層自行執行工具並回注 tool result。另一方面，Waifu 實際 Agent 路徑則主要透過 Shuvi 來做工具迴圈編排。

### 14.2 Tool 抽象

Tool 是 hai 使 LLM 可操作外部世界的核心抽象。這與 LangChain 的 tool 概念類似，但此處採自訂實作。

### 14.3 Flow

Flow 提供節點管線執行模型，支援：

- 節點鏈接執行
- timeout
- on_error handler

這使 hai 不只是一個 provider wrapper，而是具備工作流編排能力。

### 14.4 文件與資料處理

Document、loader、processor、vectorstores、graphstores 等模組顯示 hai 的設計方向不只面向聊天，也包含：

- RAG
- 文件處理
- 向量檢索
- 圖資料整合

因此，論文中可把 hai 描述為通用 AI application substrate。

---

## 15. Shuvi 的技術重點

### 15.1 兩層迴圈

Shuvi 的設計核心是兩層迴圈：

- inner loop：處理模型與工具互動
- outer loop：處理驗證與修正

這是比單次 prompt-response 更接近真正 agent runtime 的結構。

### 15.2 Execution Trace

Shuvi 會輸出 AgentResult 與 ExecutionTrace，記錄：

- token usage
- tool traces
- verifications
- 執行耗時
- outcome

這對研究 agent 可觀測性、成本分析與可靠性都有價值。

### 15.3 LoopState

LoopState 提供：

- turn_count
- pending_summary
- stop_active
- transition

這讓 Agent 能被描述為有狀態的執行機，而不是單次函數呼叫。

---

## 16. 目前測試現況

目前可見測試檔為 test/test_flow.py，內容偏向整合式驗證，而非完整單元測試矩陣。測試覆蓋方向包括：

- 基本問答
- read tool
- write tool
- shell tool

這些測試的特性是：

- 依賴實際 config.toml
- 需要真實 Waifu 實例
- 比較接近端到端驗證

因此可以判斷：

- 專案已有最小可執行驗證
- 自動化測試尚未完整
- 這也是目前開發成熟度的一個限制點

---

## 17. 已知設計方向與未完成重點

根據 localdocs 與現有程式碼，可將「現有能力」與「明顯尚在演進中的方向」分開描述。

### 17.1 已完成或已有基礎實作的重點

- uv workspace monorepo
- waifu / waifu_sdk / waifu_types 分層
- Gateway + Lane queue 對話串行化
- Hook 與 Plugin 基礎架構
- MCP bridge
- Runtime config 與 DB seed
- 對話與 token analytics 持久化
- Context budget 粗估裁切
- AgentRunner retry 與狀態追蹤
- API 控制後端多數功能

### 17.2 仍屬演進中的議題

- 更完整的 context compaction 摘要機制
- 高風險工具權限白名單與 PermissionGate
- 工具錯誤的更清晰回饋
- 更完整的測試覆蓋
- 更完整的資料庫與平台治理
- skills registry / MCP registry CLI 整合成熟化
- Live2D / lipsync 細緻度提升

這些內容在論文中應明確區分為：

- 現況功能
- 架構演進方向
- 未來工作

---

## 18. 可作為論文主軸的研究價值

### 18.1 平台化 AI Assistant Backend

Waifu 的核心價值不只是聊天，而是把 Agent、Plugin、Gateway、Memory、Config、MCP 與外部通道整合為同一後端平台。

### 18.2 可擴充性

透過：

- waifu_types 抽象層
- waifu_sdk 對外 API
- PluginManager / PluginRegistry
- MCP adapter

使系統具備良好的生態擴充空間。

### 18.3 可觀測性與可治理性

透過：

- ExecutionTrace
- QueryState
- DailyTokenUsage
- Status API
- Config API

讓系統具備 agent runtime 的觀測與治理能力。

### 18.4 多模態與多通道整合

透過：

- 圖片附件轉 image_url
- STT / TTS / lipsync
- WebSocket / SSE / Discord / Telegram

使系統從單純文字助理走向多模態互動平台。

---

## 19. 建議的論文章節切法

若要直接用於論文，可考慮以下章節：

### 第一章 緒論

- 研究背景：大型語言模型從單輪問答走向 Agent 系統
- 研究動機：需要一個可擴充、可管理、可多平台接入的 AI Assistant 後端
- 研究目標：設計並實作 Waifu 平台

### 第二章 系統需求與設計目標

- 多通道接入
- 長期對話持久化
- 插件與工具擴充
- 多角色與個人化記憶
- 可治理的 Agent Runtime

### 第三章 系統架構

- monorepo 分層
- waifu / waifu_sdk / waifu_types
- hai 與 shuvi 的角色分工
- Gateway / Hook / Plugin / Agent / Store 架構

### 第四章 關鍵技術實作

- Agent loop
- tool-calling
- context budget
- 對話模式與 lane queue
- Plugin 與 MCP
- SQLite + Markdown 持久化

### 第五章 系統介面與管理能力

- REST / WebSocket API
- CLI
- Config / Status / Character / Conversation 管理

### 第六章 實驗與評估

- 功能驗證
- token usage 與成本觀察
- 不同通道模式比較
- 工具呼叫成功率與錯誤恢復分析

### 第七章 限制與未來工作

- 更完整的摘要壓縮
- 權限治理
- 測試覆蓋
- 前後端整合與多代理擴展

---

## 20. 一句話總結

Waifu 可以被定義為：

「一個以 Python 建構、結合自有 AI 基礎層 hai 與 Agent runtime shuvi，支援多通道接入、插件擴充、對話持久化、角色化記憶與 MCP 整合的 AI Assistant 後端平台。」
