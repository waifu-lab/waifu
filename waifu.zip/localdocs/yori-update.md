# Yori 前端對接更新說明

> 更新日期：2026-04-21
> 根據後端實際實作（`waifu/gateway/adapters/websocket.py`、`waifu/gateway/adapters/waifu_node.py`、`waifu/node/manager.py`）整理。

---

## 一、端點與 session 架構

| 端點  | 用途                             | 說明                           |
|-------|----------------------------------|--------------------------------|
| `/ws` | 前端（對話、語音）               | SESSION 模式，前端直連或 Tauri 代理 |
| `/node` | waifu-node（電腦控制）         | 直接由 waifu-node Rust binary 連線，前端**不需碰** |

**waifu-node 與前端對話 session 完全獨立**，不共用同一個 `/ws` connection。
前端只需要處理 `/ws`，waifu-node 自行連 `/node`。

---

## 二、`/ws` 訊息格式（前端直接使用）

### Client → Server

```ts
// 文字對話
{
  type: "chat",
  conversation_id?: string,   // 省略時後端以 session token 當作 id
  request_id?: string,        // 省略時後端自動生成
  content: string,
  live2d?: boolean            // 是否需要口型/表情事件（可選，預設 false）
}

// 語音輸入（VAD 截取後送出）
{
  type: "voice",
  conversation_id?: string,
  request_id?: string,
  audio: string,              // base64 encoded audio
  format: "webm"
}
```

**不需要** `client_hello`，WebSocket 接受後直接收訊息。

### Server → Client

```ts
// 串流 chunk（reply 的每個 token）
{
  type: "chunk",
  request_id: string,
  content: string             // 本次 delta
}

// 回覆完成
{
  type: "done",
  request_id: string,
  content: string             // 完整回覆文字
}

// Live2D / 表情事件（在 done 之前批次送出）
{
  type: "event",
  // 後端 hook 附加的任意欄位（expression、motion、lipsync 等）
  [key: string]: any
}

// 錯誤
{
  type: "error",
  request_id?: string,
  code: string,
  message: string
}
```

> **注意**：後端實際送出的是 `chunk` / `done` / `event`，**不是** `chat_response` / `tts_audio` / `model_params`。
> 舊版文件描述的格式與實際實作不符，以本文件為準。

---

## 三、`conversation_id` 規則

- 前端第一次送訊息可省略 `conversation_id`，後端會以 `ws:{session_token}` 作為 id
- 若前端有自行管理對話分組，可傳入 `conversation_id`；後端若值不帶 `ws:` 前綴會自動補上
- `done` 訊息**目前不回傳** `conversation_id`，前端需自行維護 request_id ↔ conversation_id 的對應

---

## 四、TypeScript 型別定義（`src/lib/backend/types.ts`）

```ts
// ── Client → Server ──────────────────────────────────────────

export interface ChatMessage {
  type: "chat";
  conversation_id?: string;
  request_id?: string;
  content: string;
  live2d?: boolean;
}

export interface VoiceMessage {
  type: "voice";
  conversation_id?: string;
  request_id?: string;
  audio: string;        // base64
  format: "webm";
}

export type ClientMessage = ChatMessage | VoiceMessage;

// ── Server → Client ──────────────────────────────────────────

export interface ChunkMessage {
  type: "chunk";
  request_id: string;
  content: string;
}

export interface DoneMessage {
  type: "done";
  request_id: string;
  content: string;
}

export interface EventMessage {
  type: "event";
  [key: string]: unknown;
}

export interface ErrorMessage {
  type: "error";
  request_id?: string;
  code: string;
  message: string;
}

export type ServerMessage = ChunkMessage | DoneMessage | EventMessage | ErrorMessage;
```

---

## 五、WS 客戶端實作要點（`src/lib/backend/ws.ts`）

```ts
// dispatch 範例
function handleMessage(raw: ServerMessage) {
  switch (raw.type) {
    case "chunk":
      // 累積到對應 request_id 的 buffer
      break;
    case "done":
      // 標記完成，觸發 UI 更新
      break;
    case "event":
      // 路由到 Live2D / 表情處理
      // 透過 invoke("update_model_params", ...) 送到 Rust
      break;
    case "error":
      // 顯示錯誤
      break;
  }
}
```

---

## 六、waifu-node 相關（前端幾乎不需要處理）

waifu-node 直連後端 `/node`，與前端 `/ws` 完全獨立。
前端（Svelte）**不需要**：
- 處理任何 `node_*` 訊息
- 送出 `node_proxy`
- 帶 `node_id` 到 `/ws`（`client_hello` 目前後端也**未實作**）

唯一需要前端配合的是 **Tauri 命令**（Rust Core 負責管理 waifu-node 程序）：

```ts
invoke("agent_install")  => void
invoke("agent_start")    => void
invoke("agent_stop")     => void
invoke("agent_status")   => "Running" | "Stopped" | "UpdateAvailable"
```

這些命令由 `src-tauri/src/agent/mod.rs` 實作，前端只需在設定頁面呼叫。

---

## 七、HTTP API（`/chat`）

若不使用 WebSocket，也可透過 HTTP SSE：

```
POST /chat/
Content-Type: application/json

{
  "conversation_id": "default",
  "content": "你好",
  "user_id": "http:anonymous",    // 選填
  "display_name": "User"          // 選填
}
```

回應為 SSE 串流（`text/event-stream`），格式與 WS `chunk`/`done` 相同。

---

## 八、實作優先順序

1. `src/lib/backend/types.ts` — 定義上方 TS 型別
2. `src/lib/backend/ws.ts` — WS 連線（或 Tauri Event bridge）、chunk/done 累積
3. `src/lib/stores/chat.ts` — 對話紀錄 store
4. `src/routes/chat/+page.svelte` — 對話 UI
5. `src/lib/audio/vad.ts` + `recorder.ts` — 語音輸入
6. `src/lib/commands.ts` — `agent_*` Tauri 命令包裝
