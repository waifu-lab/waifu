# Waifu 開發進度

## ✅ Phase 1 — 骨架（已完成）
- [x] `waifu_types/` — IncomingRequest, OutgoingResponse, Sender, Attachment, ConversationMode, BaseGatewayAdapter, BaseHook, HookContext, BaseMCPAdapter, BasePlugin, PluginContext
- [x] `waifu_sdk/` — 純 re-export waifu_types（plugin 開發者輕量依賴）
- [x] `waifu/config/` — WaifuConfig, GatewayConfig, ContextConfig, ProviderConfig
- [x] `waifu/gateway/session.py` — Session, SessionManager（TTL 過期）
- [x] `waifu/gateway/lane.py` — Lane, LaneManager（per-conversation 串行）
- [x] `waifu/gateway/core.py` — GatewayCore（dispatch_handler DI 注入）
- [x] `waifu/gateway/adapters/websocket.py` — WebSocketAdapter（SESSION 模式，chunk streaming）
- [x] `waifu/hook/` — HookRegistry, HookPipeline
- [x] `waifu/plugin/` — PluginManager, PluginRegistry, _PluginContextImpl
- [x] `waifu/agent/context.py` — ContextBuilder（system_prompt + messages + tools 組裝）
- [x] `waifu/agent/runner.py` — AgentRunner（包裝 shuvi.Agent，streaming callback）
- [x] `waifu/waifu.py` — Waifu 主類（Composition Root，Fluent Builder API）

## ✅ Phase 2 — 插拔模組（已完成）
- [x] `waifu/plugin/builtin.py` — ToolPlugin, HookPlugin, MCPPlugin
- [x] `waifu/router/health.py` — GET /health
- [x] `waifu/router/ws.py` — WS /ws
- [x] `waifu/router/chat.py` — POST /chat（SSE streaming）
- [x] `waifu/router/plugin.py` — GET/POST/DELETE /plugins/*
- [x] `waifu/router/__init__.py` — include_routers()（DI 組裝）

## ✅ Phase 3 — 外部 Adapter（已完成）
- [x] `waifu/gateway/adapters/http.py` — HTTPAdapter（SSE streaming via asyncio.Queue）
- [x] `waifu/gateway/adapters/discord.py` — DiscordAdapter（DIRECT/GROUP，stream edit 模擬）
- [x] `waifu/gateway/adapters/telegram.py` — TelegramAdapter（DIRECT/GROUP，stream edit 模擬）

## ✅ Phase 4 — MCP（已完成）
- [x] `waifu/mcp/stdio.py` — StdioMCPAdapter（JSON-RPC over stdin/stdout）
- [x] `waifu/mcp/sse.py` — SSEMCPAdapter（HTTP JSON-RPC）

## ⬜ Phase 5 — 前端
- [ ] Live2D 客戶端（WebSocket + streaming UI + 情緒事件）

## ✅ Phase 6 — CLI & SDK（已完成）
- [x] `waifu/cli/` — `waifu start --config --host --port --reload`
- [x] `waifu/_cli_app.py` — 預設 FastAPI app（uvicorn 啟動時 DI 組裝）
- [x] `waifu_sdk/` — 對外 API re-export

## ✅ 內建 Hook（已完成）
- [x] `waifu/hook/builtin.py` — RateLimitHook, MemoryHook（+ InMemoryStore）, EmotionHook, LoggingHook

## ✅ 語音功能（已完成）
- [x] `hai/providers/providers.py` — ProviderSTT（Whisper）、ProviderTTS（OpenAI TTS）
- [x] `hai/providers/openai.py` — OpenAISTT、OpenAITTS
- [x] `waifu/voice/service.py` — VoiceService（STT/TTS pipeline）
- [x] `waifu/voice/lipsync.py` — estimate_duration_ms、build_lipsync_events
- [x] `waifu/hook/builtin.py` — TTSHook（post hook，合成語音 + lipsync events）
- [x] `waifu/gateway/adapters/websocket.py` — 支援 type:"voice" STT 輸入
- [x] `waifu/config/__init__.py` — STTConfig、TTSConfig、VoiceConfig

## ✅ CLI 重構（已完成）
- [x] `waifu/cli/__init__.py` — 用 rich 取代 argparse，主 dispatch + help
- [x] `waifu/cli/_console.py` — 共用 console / err_console
- [x] `waifu/cli/start.py` — waifu start（從原 __init__ 抽出）
- [x] `waifu/cli/version.py` — waifu version
- [x] `waifu/cli/config.py` — waifu config get/set/list
- [x] `waifu/cli/run.py` — waifu run（直接跑 AI pipeline）
- [x] `waifu/cli/tui.py` — waifu tui（Textual 互動聊天 TUI）
- [x] `waifu/cli/conversation.py` — waifu conversation create/delete/search/compact/messages/switch
- [x] `waifu/cli/mcp.py` — waifu mcp list（其餘 stub）
- [x] `waifu/cli/skill.py` — stub（待 skills registry 整合）
- [x] `waifu/cli/cron.py` — waifu cron list/add/remove/run/enable/disable/history

## ✅ Store 層（已完成）
- [x] `waifu/store/paths.py` — AppPaths（平台對應：Windows/macOS/Linux，DI 注入）
- [x] `waifu/store/models.py` — Peewee models：Conversation, Message, CronJob, CronRun + Database wrapper
- [x] `waifu/store/conversation.py` — ConversationStore（CRUD + search + compact）
- [x] `waifu/store/cron.py` — CronStore（job CRUD + run history）

## ⬜ 待辦
- [ ] Live2D 前端
- [ ] `waifu/cli/skill.py` — skills registry 整合（skills.sh / GitHub）
- [ ] `waifu/cli/mcp.py` — MCP registry install/uninstall/search
- [ ] 測試補全
