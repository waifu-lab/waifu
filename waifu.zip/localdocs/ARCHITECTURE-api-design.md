# API Design — Frontend ↔ Backend 完整控制介面

本文描述前端透過 REST/WebSocket 完整控制 Waifu 後端所需的 API 設計。
基於現有實作（`waifu/router/`、`waifu/service/`、`waifu/store/`）並補全缺漏端點。

---

## 總覽

```
Base URL: http://localhost:8765

已實作 (✅)     待補充 (🔲)

REST
  ✅ GET    /health
  ✅ WS     /ws
  ✅ POST   /chat
  ✅ GET    /config
  ✅ PUT    /config
  ✅ GET    /config/{key}
  ✅ PUT    /config/{key}
  ✅ GET    /plugins
  ✅ GET    /plugins/available
  ✅ POST   /plugins
  ✅ POST   /plugins/{name}/enable
  ✅ POST   /plugins/{name}/disable
  ✅ DELETE /plugins/{name}
  ✅ GET    /mcp
  ✅ POST   /mcp
  ✅ POST   /mcp/{name}/enable
  ✅ POST   /mcp/{name}/disable
  ✅ DELETE /mcp/{name}
  ✅ GET    /characters
  ✅ POST   /characters
  ✅ GET    /characters/{id}
  ✅ PUT    /characters/{id}
  ✅ DELETE /characters/{id}
  ✅ POST   /characters/{id}/activate
  ✅ GET    /characters/{id}/relationships
  ✅ GET    /characters/{id}/relationships/{uid}
  ✅ PUT    /characters/{id}/relationships/{uid}
  🔲 GET    /conversations
  🔲 GET    /conversations/{id}
  🔲 GET    /conversations/{id}/messages
  🔲 DELETE /conversations/{id}
  🔲 POST   /conversations/{id}/compact
  🔲 GET    /tools
  🔲 GET    /sessions
  🔲 DELETE /sessions/{id}
  🔲 GET    /status
```

---

## 1. 系統狀態

### `GET /health`
基本健康檢查。

**Response `200`**
```json
{ "status": "ok" }
```

---

### `GET /status` 🔲
完整運行時快照，供 Dashboard 首頁顯示。

**Response `200`**
```json
{
  "uptime_seconds": 3820,
  "active_sessions": 2,
  "active_conversations": 5,
  "plugins_loaded": ["mcp-filesystem", "web-search"],
  "mcp_servers": [{ "name": "filesystem", "enabled": true }],
  "character": "Sora",
  "provider": {
    "model": "gpt-4o",
    "base_url": "https://api.openai.com/v1"
  },
  "voice": {
    "stt_enabled": true,
    "tts_enabled": true
  }
}
```

---

## 2. 對話（Chat）

### `WS /ws`
主要即時對話通道，支援文字、語音、Live2D 事件。

**Client → Server**
```jsonc
// 文字訊息
{
  "type": "chat",
  "conversation_id": "main",       // 省略則後端自動建立
  "request_id": "uuid",
  "content": "你好！"
}

// 語音（Base64 音訊）
{
  "type": "voice",
  "conversation_id": "main",
  "request_id": "uuid",
  "audio": "<base64>",
  "format": "webm"
}
```

**Server → Client**
```jsonc
// 文字 chunk（streaming）
{ "type": "chunk", "request_id": "uuid", "content": "你" }

// 完成
{
  "type": "done",
  "request_id": "uuid",
  "conversation_id": "main",
  "usage": { "prompt_tokens": 100, "completion_tokens": 50 },
  "trace": { "steps": [...], "tool_calls": [...] }
}

// Live2D 情緒事件
{ "type": "event", "event": "emotion", "data": { "emotion": "happy" } }

// Live2D 動作事件
{ "type": "event", "event": "motion", "data": { "motion": "wave" } }

// TTS 音訊
{ "type": "audio", "request_id": "uuid", "data": "<base64>", "lipsync": [...] }

// 錯誤
{ "type": "error", "request_id": "uuid", "code": "rate_limit", "message": "..." }
```

---

### `POST /chat`
HTTP SSE 對話（無 WebSocket 環境備用）。

**Request**
```json
{
  "conversation_id": "default",
  "content": "你好",
  "user_id": "http:anonymous",
  "display_name": "User"
}
```

**Response** `text/event-stream`
```
data: {"type":"chunk","content":"你"}
data: {"type":"chunk","content":"好！"}
data: {"type":"done","usage":{...}}
```

---

## 3. 對話歷史 🔲

### `GET /conversations`
列出所有對話（按最後更新排序）。

**Query**
| 參數 | 型別 | 預設 | 說明 |
|------|------|------|------|
| `limit` | int | 20 | 最多回傳筆數 |
| `q` | string | — | 全文搜尋（標題或訊息內容） |

**Response `200`**
```json
[
  {
    "id": "ws:abc123",
    "title": "ws:abc123",
    "created_at": "2026-04-19T10:00:00Z",
    "updated_at": "2026-04-19T10:30:00Z",
    "message_count": 12
  }
]
```

---

### `GET /conversations/{id}`
取得單一對話摘要。

**Response `200`**
```json
{
  "id": "ws:abc123",
  "title": "ws:abc123",
  "created_at": "2026-04-19T10:00:00Z",
  "updated_at": "2026-04-19T10:30:00Z",
  "message_count": 12
}
```

---

### `GET /conversations/{id}/messages`
取得對話中所有訊息（含工具呼叫記錄）。

**Query**
| 參數 | 型別 | 預設 | 說明 |
|------|------|------|------|
| `limit` | int | 100 | 最多回傳筆數，0 = 全部 |

**Response `200`**
```json
[
  {
    "id": "msg-uuid",
    "role": "user",
    "parts": [{ "type": "text", "text": "你好！" }],
    "created_at": "2026-04-19T10:00:00Z"
  },
  {
    "id": "msg-uuid-2",
    "role": "assistant",
    "parts": [
      { "type": "text", "text": "你好！有什麼可以幫你的？" }
    ],
    "created_at": "2026-04-19T10:00:01Z"
  }
]
```

> `parts` 型別：
> - `{ "type": "text", "text": "..." }` — 一般文字
> - `{ "type": "tool-{name}", "toolName": "...", "args": {...} }` — 工具呼叫
> - `{ "type": "tool-result", "toolCallId": "...", "result": "..." }` — 工具結果

---

### `DELETE /conversations/{id}`
刪除對話及其所有訊息。

**Response `200`**
```json
{ "id": "...", "status": "deleted" }
```

---

### `POST /conversations/{id}/compact`
壓縮對話歷史（刪除較舊訊息，保留最近 N 輪）。

**Response `200`**
```json
{ "id": "...", "deleted_count": 42, "status": "compacted" }
```

---

## 4. 配置管理

所有配置以 `section.field` 點式 key 儲存於 SQLite `app_config` 表。
部分 key 為「熱更新」（無需重啟）：`provider.model`、`provider.temperature`、
`provider.max_tokens`、`context.system_prompt_template`、
`context.max_history_messages`、`context.history_strategy`。

### `GET /config`
取得所有配置。

**Response `200`**
```json
{
  "gateway.host": "localhost",
  "gateway.port": 8765,
  "gateway.session_ttl": 3600,
  "gateway.lane_max_queue": 10,
  "context.system_prompt_template": "You are a helpful assistant.",
  "context.max_history_messages": 20,
  "context.history_strategy": "sliding",
  "provider.model": "gpt-4o",
  "provider.base_url": "https://api.openai.com/v1",
  "provider.api_key": "sk-...",
  "provider.temperature": 0.7,
  "provider.max_tokens": null,
  "provider.stream": true
}
```

---

### `PUT /config`
批次更新多個 key（熱更新 key 立即生效）。

**Request**
```json
{
  "provider.model": "gpt-4o-mini",
  "provider.temperature": 0.5,
  "context.max_history_messages": 30
}
```

**Response `200`**
```json
{
  "provider.model": { "key": "provider.model", "status": "saved" },
  "provider.temperature": { "key": "provider.temperature", "status": "saved" },
  "context.max_history_messages": { "key": "context.max_history_messages", "status": "saved" }
}
```

---

### `GET /config/{key}`
取得單一 key。

**Example** `GET /config/provider.model`

**Response `200`**
```json
{ "key": "provider.model", "value": "gpt-4o" }
```

**Response `404`**
```json
{ "detail": "Config key 'xxx' not found" }
```

---

### `PUT /config/{key}`
更新單一 key。

**Request**
```json
{ "value": "gpt-4o-mini" }
```

**Response `200`**
```json
{ "key": "provider.model", "status": "saved" }
```

> `gateway.*` 的 key 回傳附加 `"note": "requires restart"`。

---

## 5. Plugin 管理

Plugin 為本地 Python 套件（放在 `~/.waifu/plugins/` 資料夾）。

### `GET /plugins/available`
列出本地可安裝的 Plugin。

**Response `200`**
```json
[
  {
    "name": "web-search",
    "version": "1.0.0",
    "description": "DuckDuckGo 搜尋",
    "config_schema": {
      "max_results": { "type": "integer", "default": 5 }
    }
  }
]
```

---

### `GET /plugins`
列出目前已安裝（載入）的 Plugin。

**Response `200`**
```json
[
  {
    "name": "web-search",
    "version": "1.0.0",
    "state": "enabled",
    "config": { "max_results": 5 }
  }
]
```

---

### `POST /plugins`
安裝並載入 Plugin。

**Request**
```json
{
  "plugin_name": "web-search",
  "config": { "max_results": 10 }
}
```

**Response `200`**
```json
{ "status": "installed", "name": "web-search" }
```

**Response `404`** — plugin 資料夾不存在
**Response `500`** — on_load() 失敗

---

### `POST /plugins/{name}/enable`
重新啟用已停用的 Plugin。

**Response `200`**
```json
{ "status": "enabled", "name": "web-search" }
```

---

### `POST /plugins/{name}/disable`
停用 Plugin（保留配置，不移除）。

**Response `200`**
```json
{ "status": "disabled", "name": "web-search" }
```

---

### `DELETE /plugins/{name}`
卸載並移除 Plugin。

**Response `200`**
```json
{ "status": "uninstalled", "name": "web-search" }
```

---

## 6. MCP Server 管理

MCP（Model Context Protocol）允許掛載外部工具服務。

### `GET /mcp`
列出所有已登錄的 MCP Server。

**Response `200`**
```json
[
  { "name": "filesystem", "type": "stdio", "enabled": true },
  { "name": "browser", "type": "sse", "enabled": false }
]
```

---

### `POST /mcp`
新增並連線 MCP Server。

**Request（stdio）**
```json
{
  "name": "filesystem",
  "type": "stdio",
  "command": ["npx", "-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
}
```

**Request（SSE）**
```json
{
  "name": "browser",
  "type": "sse",
  "url": "http://localhost:3001/sse"
}
```

**Response `200`**
```json
{ "status": "added", "name": "filesystem" }
```

**Response `500`** — 連線失敗（進程無法啟動 / URL 不可達）

---

### `POST /mcp/{name}/enable`
重新連線並啟用 MCP Server。

**Response `200`**
```json
{ "status": "enabled", "name": "filesystem" }
```

---

### `POST /mcp/{name}/disable`
斷線並停用 MCP Server。

**Response `200`**
```json
{ "status": "disabled", "name": "filesystem" }
```

---

### `DELETE /mcp/{name}`
移除 MCP Server（斷線 + 從 DB 刪除）。

**Response `200`**
```json
{ "status": "removed", "name": "filesystem" }
```

---

## 7. 工具列表 🔲

查詢目前 Agent 可呼叫的所有工具（本地 Tool + MCP 工具的聯集）。

### `GET /tools`
列出所有已載入工具。

**Response `200`**
```json
[
  {
    "name": "read_file",
    "description": "讀取本地檔案內容",
    "source": "mcp:filesystem",
    "parameters": {
      "type": "object",
      "properties": {
        "path": { "type": "string" }
      },
      "required": ["path"]
    }
  },
  {
    "name": "web_search",
    "description": "DuckDuckGo 搜尋",
    "source": "plugin:web-search",
    "parameters": { ... }
  }
]
```

---

## 8. 角色（Character）管理

### `GET /characters`
列出所有角色。

**Response `200`**
```json
[
  {
    "id": "char-uuid",
    "name": "Sora",
    "soul_path": "/home/user/.waifu/characters/Sora/soul.md",
    "avatar_path": "/home/user/.waifu/characters/Sora/avatar.png",
    "live2d_dir": "/home/user/.waifu/characters/Sora/live2d",
    "active": true
  }
]
```

---

### `POST /characters`
新增角色。

**Request**
```json
{
  "name": "Sora",
  "soul_path": "/absolute/path/to/soul.md",
  "avatar_path": "/absolute/path/to/avatar.png",
  "live2d_dir": "/absolute/path/to/live2d"
}
```

**Response `200`**
```json
{ "id": "char-uuid", "name": "Sora", "status": "created" }
```

---

### `GET /characters/{id}`
取得角色詳情。

**Response `200` / `404`**

---

### `PUT /characters/{id}`
更新角色資訊（部分更新）。

**Request**（任意欄位）
```json
{ "soul_path": "/new/path/soul.md" }
```

**Response `200`**
```json
{ "id": "char-uuid", "status": "updated" }
```

---

### `DELETE /characters/{id}`
刪除角色。

**Response `200`**
```json
{ "id": "char-uuid", "status": "deleted" }
```

---

### `POST /characters/{id}/activate`
設為當前使用中角色（同時取消其他角色的 active）。

**Response `200`**
```json
{ "id": "char-uuid", "status": "activated" }
```

---

### `GET /characters/{id}/relationships`
列出角色與所有用戶的關係記錄。

**Response `200`**
```json
[
  {
    "user_id": "discord:user:123456",
    "display_name": "Alice",
    "notes": "喜歡聽爵士樂，常在深夜上線",
    "memory_path": "/home/user/.waifu/memory/Sora/direct/discord:user:123456.md"
  }
]
```

---

### `GET /characters/{id}/relationships/{uid}`
取得單一用戶關係詳情。

**Response `200` / `404`**

---

### `PUT /characters/{id}/relationships/{uid}`
更新關係備忘（角色記住的事）。

**Request**
```json
{
  "notes": "喜歡聽爵士樂，有一隻叫 Mochi 的貓",
  "display_name": "Alice"
}
```

**Response `200`**
```json
{ "status": "updated" }
```

---

## 9. Session 管理 🔲

Session 是記憶體內的短期狀態（TTL 預設 3600s）。

### `GET /sessions`
列出當前所有活躍 Session。

**Response `200`**
```json
[
  {
    "conversation_id": "ws:abc123",
    "message_count": 8,
    "metadata": {},
    "last_active": "2026-04-19T10:28:00Z"
  }
]
```

---

### `DELETE /sessions/{conversation_id}`
強制終止並清除 Session（不影響 DB 中的對話歷史）。

**Response `200`**
```json
{ "conversation_id": "ws:abc123", "status": "cleared" }
```

---

## 10. 完整互動流程圖

```
前端                           後端 API
 │                               │
 │  GET /status                  │  ← 載入 Dashboard，取得系統概況
 │  GET /config                  │  ← 顯示配置面板
 │  GET /characters              │  ← 顯示角色選擇
 │  GET /plugins                 │  ← 顯示已安裝插件
 │  GET /mcp                     │  ← 顯示 MCP 伺服器狀態
 │  GET /tools                   │  ← 顯示可用工具清單
 │                               │
 │  WS /ws  ──────────────────→  │  ← 開啟對話 WebSocket
 │   ↑ { type:"chat", ... }      │
 │   ↓ { type:"chunk", ... }     │  streaming 回應
 │   ↓ { type:"event", ... }     │  Live2D 情緒事件
 │   ↓ { type:"audio", ... }     │  TTS 音訊
 │   ↓ { type:"done", ... }      │
 │                               │
 │  GET /conversations           │  ← 側欄列出歷史對話
 │  GET /conversations/{id}/messages │  ← 切換對話時載入訊息
 │                               │
 │  PUT /config/provider.model   │  ← 即時切換模型（熱更新，無需重啟）
 │  PUT /config                  │  ← 批次調整參數
 │                               │
 │  POST /mcp                    │  ← 動態新增 MCP Server
 │  POST /plugins                │  ← 安裝插件
 │  POST /characters/{id}/activate │  ← 切換角色（影響下一輪對話）
```

---

## 11. 錯誤碼規範

| HTTP | 情境 |
|------|------|
| 400 | 請求欄位缺失或格式錯誤 |
| 404 | 資源不存在（plugin / mcp / character / config key） |
| 409 | 名稱衝突（同名 MCP / plugin 已存在） |
| 500 | 後端執行失敗（on_load 拋例外、MCP 連線失敗等） |

所有錯誤回傳：
```json
{ "detail": "Human-readable error message" }
```

---

## 12. 待補實作清單

| 優先 | 端點 | 說明 |
|------|------|------|
| 高 | `GET /conversations` | CLI 已有 ConversationStore.list()，接 router 即可 |
| 高 | `GET /conversations/{id}/messages` | ConversationStore.get_messages_as_dicts() 已實作 |
| 高 | `DELETE /conversations/{id}` | ConversationStore.delete() 已實作 |
| 高 | `GET /tools` | PluginRegistry.get_all_tools() 已有，加序列化 |
| 中 | `GET /status` | 聚合多個 service 狀態 |
| 中 | `POST /conversations/{id}/compact` | ConversationStore.compact() 已實作 |
| 中 | `GET /sessions` | GatewayCore.session_manager 已有 |
| 低 | `DELETE /sessions/{id}` | SessionManager 需加 clear() 方法 |
| 低 | `PUT /characters/{id}/relationships/{uid}` 的 `memory_path` 讀取 | 需整合 FileMemoryStore |
