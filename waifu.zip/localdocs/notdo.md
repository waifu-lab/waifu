
---

## 未完成項目進度報告

### 🔴 完全未實作

| 項目                            | 說明                                                                                                                                |
| ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| **工具權限分層 (#3)**           | `ToolRisk` enum、`PermissionGate`、`allowed_shell_commands` 白名單全部不存在。所有工具（含高風險 shell）一視同仁塞進 PluginRegistry |
| **System Prompt 分層架構 (#5)** | `build_system_prompt()` 直接字串拼接，無 `SystemPromptLayers` 結構                                                                  |
| **安全模式**                    | 全專案無任何 `safe_mode` 相關程式碼                                                                                                 |
| **換掉 peewee**                 | 整個 store 層仍使用 peewee。`models.py` 定義 6 個 peewee 模型，pyproject.toml 依賴未替換                                            |
| **實作 Rich logging**           | 雖有 `from rich import ...` 用於 CLI 顯示，但 logging 仍是標準 `logging.basicConfig()`，無 `RichHandler`                            |

---

### 🟡 部分實作

| 項目                               | 已完成                                                                                    | 缺少                                                                         |
| ---------------------------------- | ----------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
| **Context Budget LLM 壓縮 (#2)**   | token 估算（chars/4）+ 滑窗裁切、`context_token_budget` / `compact_threshold` config 欄位 | LLM 摘要壓縮（超限時呼叫模型產生摘要）                                       |
| **中斷 in-flight request id (#7)** | `CancelledError` 捕捉 + 寫入 `〔已中斷〕` placeholder                                     | Session 層無 request id 追蹤，重連時無主動通知                               |
| **LLM_MESSAGE vs UI_MESSAGE (#6)** | `add_llm_message()` + MemoryHook 儲存完整工具歷史                                         | 無明確 MessageType enum 區分，尚未統一類型系統                               |
| **Cron 功能**                      | CLI 介面完整（list/add/remove/run/enable/disable）、CronStore CRUD、DB models             | 無 scheduler daemon、無 cron expression 解析、無執行框架，功能尚未接入主系統 |
| **心跳功能**                       | `waifu_node` adapter 有 `_ping_task` / `_ping_interval` 基礎設施                          | 主 `WebSocketAdapter` 無 heartbeat，無通用 ping-pong 機制                    |
| **工具調用失敗指示**               | AgentRunner retry 邏輯、`waifu_node` 有 TOOL_ERROR code                                   | 無使用者可見的失敗訊息、無 LLM 訊息流中的失敗指示                            |
| **MCP CLI**                        | `list` 完整實作（讀 config 顯示 MCP server）                                              | `install` / `uninstall` / `search` 皆為 TODO stub                            |

---

### 🟠 僅有 Stub（骨架但無實作）

| 項目         | 說明                                                                                                  |
| ------------ | ----------------------------------------------------------------------------------------------------- |
| **skill.py** | 所有子命令（list/search/install/update/uninstall）都回傳 `TODO: requires skills registry integration` |

---

### ✅ 實際上已接近完成（feature.md 標記 `[ ]` 但代碼有大量實作）

| 項目                 | 說明                                                               |
| -------------------- | ------------------------------------------------------------------ |
| **hai 擴充 AI 端點** | 已有 OpenAI、Anthropic、Google、Ollama 四個 provider，主要端點齊全 |

---

### 其他功能類項目（需前端或特殊硬體配合）

這些項目屬於較長期規劃，目前代碼層幾乎無實作：
- **模型驅動的動作**、**低延遲語音管線（VAD整合）**、**環境感知（螢幕識別）**
- **桌面寵物自主走動**、**用戶離開檢測**
- **history tree 視覺化**、**Discord/Telegram 測試**
- **重度更新（對話 AI 與操作 AI 分離）**、**添加工具 AI**
- **滑鼠穿透問題**（前端議題）

---

**建議優先處理順序（安全/穩定性優先）：**
1. 🔴 工具權限 shell 白名單（P1 安全隱患）
2. 🟡 Cron scheduler daemon 接入主系統
3. 🟡 Rich logging 整合（低成本高回報）
4. 🔴 System Prompt 分層（維護性改善）