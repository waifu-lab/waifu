# Waifu Backend — Node 整合更新說明

> 本文件描述為支援 waifu-node 整合所需新增的後端模組與修改點。
> 閱讀前請先熟悉 `Waifu-Node.md`（節點協議）。

---

## 新增模組總覽

```
waifu/
├── gateway/
│   └── adapters/
│       └── node.py          # NodeAdapter（新增）
├── node/                    # 新增目錄
│   ├── __init__.py
│   ├── registry.py          # NodeRegistry：連線管理 + session 綁定
│   ├── executor.py          # NodeToolExecutor：tool call 路由到正確 node
│   └── skill_manager.py     # SkillManager：skill 生命週期 + 檔案服務
├── router/
│   └── skills.py            # HTTP 路由：skill 安裝、檔案下載（新增）
└── plugin/
    └── node_plugin.py       # NodePlugin：將 node tools 注入 PluginManager（新增）
```

---

## 一、NodeAdapter

**位置**：`waifu/gateway/adapters/node.py`

負責管理 `/node` WebSocket 端點，處理所有 node 連線的生命週期。

### 掛載方式

```python
from waifu.gateway.adapters.node import NodeAdapter

node_adapter = NodeAdapter()
node_adapter.mount(app, path="/node")

waifu = (
    Waifu(config)
    .mount(ws_adapter)
    .mount(node_adapter)   # 新增
    ...
)
```

### 核心職責

1. **接收 `node_hello`**：驗證 token、版本，建立 node 連線記錄
2. **回傳 `node_welcome` 或 `node_reject`**
3. **觸發 skill 同步**：比對 backend 已安裝 skill 與 node `installed_skills`，送出需要更新的 `node_skill_sync`
4. **維護 ping/pong**：每 30s 送出，未回應則標記離線
5. **轉發 `node_result`**：對應 pending `node_invoke` 的 future，解除等待

### 訊息處理

```python
class NodeAdapter:
    async def on_node_hello(self, ws, message: NodeHello):
        # 1. 驗證
        if not self._auth(message.token):
            await ws.send_json({"type": "node_reject", "code": "AUTH_FAILED", ...})
            return

        # 2. 注冊到 NodeRegistry
        node = await registry.register(ws, message)

        # 3. 歡迎
        await ws.send_json({"type": "node_welcome", "session_id": node.session_id, ...})

        # 4. 比對 skill，送出需要同步的項目
        await skill_manager.sync_to_node(node)

        # 5. 注入 tools 到 PluginManager
        await node_plugin.register_node_tools(node)

    async def on_node_skill_ready(self, ws, message: NodeSkillReady):
        node = registry.get_by_ws(ws)
        # 該 skill 的 tools 現在可以被 Agent 使用
        await node_plugin.enable_skill_tools(node, message.skill_id)

    async def on_node_result(self, ws, message: NodeResult):
        # 解除對應 request_id 的 asyncio.Future
        await registry.resolve(message.request_id, message)

    async def on_node_bye(self, ws, message):
        await registry.unregister(ws)
        await node_plugin.unregister_node_tools(registry.get_by_ws(ws))
```

---

## 二、NodeRegistry

**位置**：`waifu/node/registry.py`

核心資料結構，維護兩張映射表：

```python
class NodeRegistry:
    # node_id → NodeConnection
    _nodes: dict[str, NodeConnection]

    # session_id → node_id（session 與 node 的綁定）
    _session_node: dict[str, str]

    # request_id → asyncio.Future（等待 node_result）
    _pending: dict[str, asyncio.Future]
```

### NodeConnection

```python
@dataclass
class NodeConnection:
    node_id: str
    session_id: str         # 由 NodeRegistry 分配
    display_name: str       # 來自 node_hello，用於多 node 工具命名
    platform: str
    caps: list[str]
    skills_dir: str
    installed_skills: list[SkillInfo]
    ws: WebSocket
    connected_at: datetime
    last_ping: datetime
```

### session_node 綁定規則

```python
async def register(self, ws: WebSocket, hello: NodeHello) -> NodeConnection:
    node = NodeConnection(...)
    self._nodes[node.node_id] = node

    # ws 模式（直連 /node）：node 自成一個虛擬 session
    virtual_session = f"node:{node.node_id}"
    self._session_node[virtual_session] = node.node_id

    return node

async def bind_tauri_session(self, session_id: str, node_id: str):
    """
    Tauri 送出 client_hello 時帶 node_id，呼叫此方法建立綁定。
    session_id 為 Tauri WS session（ws:{token}）。
    """
    self._session_node[session_id] = node_id
```

### invoke（送出並等待結果）

```python
async def invoke(self, node_id: str, action: str, params: dict, timeout_ms: int = 10000) -> dict:
    node = self._nodes.get(node_id)
    if not node:
        raise NodeError("NODE_OFFLINE", f"node {node_id} not connected")

    request_id = str(uuid4())
    future: asyncio.Future = asyncio.get_event_loop().create_future()
    self._pending[request_id] = future

    await node.ws.send_json({
        "type": "node_invoke",
        "request_id": request_id,
        "action": action,
        "params": params,
    })

    try:
        result = await asyncio.wait_for(future, timeout=timeout_ms / 1000)
    except asyncio.TimeoutError:
        del self._pending[request_id]
        raise NodeError("INVOKE_TIMEOUT", f"node did not respond within {timeout_ms}ms")

    if not result["ok"]:
        raise NodeError(result["error"]["code"], result["error"]["message"])

    return result["data"]

async def resolve(self, request_id: str, result: NodeResult):
    future = self._pending.pop(request_id, None)
    if future and not future.done():
        future.set_result(result.dict())
```

---

## 三、NodeToolExecutor

**位置**：`waifu/node/executor.py`

實作 `hai.tool.Tool` 介面，是 node capability 在 PluginManager 中的執行入口。

```python
class NodeToolExecutor:
    def __init__(self, registry: NodeRegistry):
        self.registry = registry

    async def call(self, action: str, params: dict, ctx: PluginContext) -> str:
        # session_id → node_id
        node_id = self.registry.session_node_lookup(ctx.session_id)

        if not node_id:
            raise ToolError("NO_NODE", "此 session 沒有連接的 waifu-node，請確認 waifu-node 已啟動並連線")

        result = await self.registry.invoke(node_id, action, params)
        return json.dumps(result, ensure_ascii=False)
```

### PluginContext 的 session_id

`AgentRunner` 在每次 tool call 時必須將當前 `ctx.session_id` 傳入 `PluginContext`。
這是路由的唯一依據，**確認 AgentRunner 有正確傳遞此欄位**。

---

## 四、NodePlugin

**位置**：`waifu/plugin/node_plugin.py`

負責將 node 宣告的 tools 動態注入 PluginManager，讓 Agent 無感知地使用。

### 單 node 情境

Tool 名稱保持原始：`exec`、`screenshot` 等。

### 多 node 情境

超過一台 node 連線時，自動加上 `@display_name` 後綴：

```python
def make_tool_name(action: str, node: NodeConnection, total_nodes: int) -> str:
    if total_nodes == 1:
        return action
    return f"{action}@{node.display_name}"
    # e.g. "exec@home-pc", "screenshot@work-mac"
```

### SKILL.md 注入

```python
async def enable_skill_tools(self, node: NodeConnection, skill_id: str):
    skill = skill_manager.get(skill_id)

    # SKILL.md 內容注入為 tool description
    tool = NodeSkillTool(
        name=f"run_{skill_id}",
        description=skill.skill_md_content,   # 完整 SKILL.md 給 LLM 讀
        node=node,
        skills_dir=node.skills_dir,
        executor=self.executor,
    )
    plugin_manager.register(tool)
```

`NodeSkillTool` 是一個特殊 tool，description 為完整 `SKILL.md` 內容。
LLM 讀取後自行決定呼叫哪些 node capability、組裝 exec 參數（含 scripts 路徑）。

---

## 五、SkillManager

**位置**：`waifu/node/skill_manager.py`

管理後端 skill 的安裝與版本，並驅動 node 端的同步。

### 資料結構

```python
@dataclass
class SkillPackage:
    skill_id: str
    version: str
    skill_md_content: str          # SKILL.md 完整內容，注入 LLM
    files: list[SkillFile]         # scripts/ + assets/ 的檔案清單（含 sha256）
    installed_at: datetime
```

### 同步邏輯

```python
async def sync_to_node(self, node: NodeConnection):
    for skill in self.list_skills():
        installed = node.get_installed_skill(skill.skill_id)

        if installed and installed.version == skill.version:
            continue   # 版本相符，跳過

        await node.ws.send_json({
            "type": "node_skill_sync",
            "skill_id": skill.skill_id,
            "version": skill.version,
            "base_url": config.base_url,
            "files": [
                { "path": f.path, "sha256": f.sha256, "size": f.size }
                for f in skill.files
                # 不包含 SKILL.md
            ]
        })
```

---

## 六、HTTP 路由新增

**位置**：`waifu/router/skills.py`，掛載於 `/skills`

```python
# 列出已安裝 skill
GET  /skills
→ [{ "skill_id": "ocr-skill", "version": "1.2.0", "installed_at": "..." }]

# 取得 skill manifest（後端內部版本）
GET  /skills/{skill_id}
→ { "skill_id": ..., "version": ..., "files": [...] }

# node 下載 skill 檔案（支援 Range header 斷點續傳）
GET  /skills/{skill_id}/files/{path:path}
→ 檔案串流

# 安裝 skill（zip 上傳）
POST /skills/install
Content-Type: multipart/form-data
file: <skill-package.zip>
→ { "skill_id": ..., "version": ..., "status": "installed" }

# 移除 skill
DELETE /skills/{skill_id}
→ { "status": "removed" }
```

安裝後自動對所有已連線的 node 呼叫 `skill_manager.sync_to_node()`。

---

## 七、WebSocketAdapter 修改

**位置**：`waifu/gateway/adapters/websocket.py`

新增處理 `node_proxy` 訊息（IPC 模式下 Tauri 代理 node 訊息）與 `client_hello` 中的 `node_id`：

```python
async def on_message(self, ws, data: dict):
    match data["type"]:
        case "client_hello":
            session = await session_manager.create(ws, data["session_token"])
            # 新增：若帶有 node_id，建立 session → node 綁定
            if node_id := data.get("node_id"):
                await registry.bind_tauri_session(session.session_id, node_id)

        case "node_proxy":
            # Tauri IPC 模式：解包 payload，路由到 NodeAdapter 的訊息處理器
            payload = data["payload"]
            node_ws = registry.get_ws_by_tauri_session(session.session_id)
            await node_adapter.handle_message(node_ws, payload)

        case "chat" | "voice":
            # 原有邏輯不變
            ...
```

### `client_hello` 格式（新增 `node_id`）

```jsonc
{
  "type": "client_hello",
  "session_token": "xxx",
  "node_id": "uuid-of-managed-node"   // Tauri 啟動 waifu-node 時已知其 node_id
}
```

---

## 八、waifu backend config 新增

`config.toml`：

```toml
[node]
enabled = true
path = "/node"
token = ""
invoke_timeout_ms = 10000
ping_interval_s = 30

[skills]
storage_path = "./skills"       # skill 包的儲存路徑
```

---

## 九、實作順序

```
Step 1：NodeRegistry（純資料結構，無外部依賴）
Step 2：NodeAdapter（/node WS 端點，hello/bye/result）
Step 3：NodeToolExecutor + NodePlugin（tool 注入 PluginManager）
Step 4：WebSocketAdapter 修改（client_hello node_id + node_proxy）
Step 5：SkillManager + /skills HTTP 路由
Step 6：NodeSkillTool（SKILL.md 注入 description）
```

---

## 十、Agent 視角（變化最小化）

Agent（Shuvi）完全不知道 node 的存在。它只看到 PluginManager 提供的 tool 清單：

```
單台 node 情境：
  exec, screenshot, sysinfo, key_press, mouse_click, ...
  run_ocr-skill, run_auto-typer, ...

多台 node 情境：
  exec@home-pc, screenshot@home-pc, run_ocr-skill@home-pc, ...
  exec@work-mac, screenshot@work-mac, ...
```

System prompt 在多台情境下補充說明（由 NodePlugin 注入）：

```
你有以下機器可以控制：
- home-pc（Windows 11，已連線）
- work-mac（macOS 14，已連線）

呼叫工具時請使用對應的 @machine 後綴。
```

路由、同步、session 綁定全在框架層處理，對 Agent 邏輯零侵入。