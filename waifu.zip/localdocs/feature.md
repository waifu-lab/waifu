---
## Agent Runtime 設計改進（對照 A 系列清單）

### 1. Query Loop 狀態管理（A.1 / A.10.1）

- [x] 已實作：`QueryState` dataclass（turn_count / consecutive_failures / transition）、`AgentRunner` try/except + retry（最多 1 次）

**現狀**：`AgentRunner.run()` 直接把所有責任委託給 `shuvi.Agent.run()`，waifu 層完全看不到 turn 計數、工具執行狀態、恢復語義。`_dispatch` 如果 `agent.run()` 拋出例外，整個 request 直接失敗，沒有任何恢復分支。

**問題**：
- 沒有 `turnCount`、`toolUseContext`、`hasAttemptedReactiveCompact` 等跨輪狀態
- 工具呼叫失敗後無法繼續推進任務（清單中已有 `[ ]工具調用失敗沒有很明確的指示`）
- 使用者打斷時沒有懸空 tool result 的收尾機制

**改進方向**：
```python
# AgentRunner 應該暴露 / 追蹤以下狀態
class QueryState:
    turn_count: int = 0
    consecutive_failures: int = 0
    has_attempted_compact: bool = False
    pending_tool_results: list  # 未完成的工具調用賬本
    budget_tokens_remaining: Optional[int]
    transition: Literal["running", "done", "failed", "recovering"]
```
至少在 `AgentRunner` 層包一個 try/except + retry（最多 N 次），區分「可恢復錯誤」和「不可恢復錯誤」再決定是否 surface 給使用者。

---

### 2. Context Budget（上下文預算）機制（A.4 / A.1）

- [x] 已實作：`ContextBuilder.build_context_manager()` token 估算（chars / 4）+ 超閾值滑窗裁切；`ContextConfig` 新增 `context_token_budget` / `compact_threshold`
- [ ] 未實作：LLM 摘要壓縮（超限時呼叫模型產生摘要替換舊訊息段）

**現狀**：`MemoryHook` 只用 `max_history_messages` 按訊息條數截斷歷史，不管 token 數。沒有任何 compact / 壓縮機制。當對話很長時，只能被動截掉舊訊息，語義資訊直接丟失。

**問題**：
- 截斷 = 強硬丟棄，不是語義壓縮
- 沒有 compact 輸出空間的預留概念
- 沒有針對「context 即將超限」的自救路徑

**改進方向**：
- 在 `ContextBuilder.build_context_manager()` 加入 token 計數估算（字符數 / 4 作粗估即可）
- 超過預算閾值時，觸發 **摘要壓縮**：讓模型先對舊訊息產生摘要，再以摘要替換原始訊息段
- `MemoryHook.pre()` 改為：先嘗試完整歷史，若超 budget 則走摘要路徑，最後才截斷

```python
# 建議加入 HookContext 或 ContextBuilder
context_budget: TokenBudget = TokenBudget(
    max_tokens=8192,
    reserved_for_output=1024,
    compact_threshold=0.85,  # 超過 85% 時觸發壓縮
)
```

---

### 3. 工具權限分層（A.3 / A.10.2）

- [ ] 未實作：ToolRisk 分級、PermissionGate、`allowed_shell_commands` 白名單

**現狀**：`_register_builtin_tools()` 將 `read_tool`、`write_tool`、`shell_tool`、`webfetch_tool` 一視同仁地全部塞進 `PluginRegistry`。沒有任何 allow/deny/ask 語義分叉。`shell_tool` 和 `read_tool` 在治理上完全一樣。

**問題**：
- 高風險工具（shell）沒有額外確認機制
- 使用者沒辦法設定「哪些工具需要問我」
- 工具執行因果鏈只靠 `LoggingHook` 的 log，沒有結構化可查詢的 audit trail

**改進方向**：
```python
class ToolRisk(Enum):
    LOW = "low"      # read_tool, webfetch → 直接執行
    MEDIUM = "medium" # write_tool → 記錄，可設定需確認
    HIGH = "high"    # shell_tool → 預設需要確認或明確 allow list

# PluginRegistry 加入風險等級標記
registry.add_tool(shell_tool, risk=ToolRisk.HIGH)

# AgentRunner 執行工具前過一層 PermissionGate
decision = permission_gate.check(tool_name, tool_input, ctx)
# decision ∈ {allow, deny, ask}
```
最小可行版：在 config 加 `allowed_shell_commands: list[str]`，shell_tool 執行前比對白名單。

---

### 4. 錯誤恢復與熔斷（A.5 / A.10.4）

- [x] 已實作：`_dispatch` try/except fallback（寫入 placeholder assistant 訊息保持 transcript 閉環）、`QueryState.consecutive_failures` 計數
- [ ] 未實作：`session.degraded` 旗標、前端警告顯示

**現狀**：`_dispatch` 對 `agent_runner.run()` 沒有任何錯誤處理。若 shuvi Agent 拋出例外，整個請求失敗，session 歷史可能停在不一致狀態（使用者訊息已寫入 `conversation_store`，但 assistant 回應沒有）。

**問題**：
- 沒有區分「完成、失敗、恢復、繼續」這四種終止語義
- 失敗後沒有熔斷，下一輪請求可能在污染的狀態上繼續
- 沒有 `consecutive_failures` 計數和最大自動恢復次數限制

**改進方向**：
```python
# _dispatch 包一層恢復邏輯
try:
    result = await self._agent_runner.run(ctx, ...)
except RecoverableError as e:
    # 第一層：低破壞性 — 重試一次
    result = await self._agent_runner.run(ctx, ...)
except ContextOverflowError:
    # 第二層：壓縮後重試
    ctx = await self._compact_context(ctx)
    result = await self._agent_runner.run(ctx, ...)
except Exception as e:
    # 不可恢復：surface 給使用者，標記 session 狀態為 degraded
    session.mark_degraded()
    return self._build_error_response(request, e)
```
搭配 `session.degraded` 旗標，讓前端可以顯示警告而非靜默失敗。

---

### 5. System Prompt 分層架構（A.2）

- [x] 未實作：`SystemPromptLayers` 分層結構

**現狀**：`ContextBuilder.build_system_prompt()` 產出單一字串，身份描述、行為規則、工具約束、輸出格式全部混在一起。無法獨立維護各層。

**問題**：
- 新增功能時都往 prompt 加段落，長期會膨脹
- 無法知道哪段 prompt 真正影響行為（刪掉也不會有結構性變化）
- 優先級不明確（config 預設 vs 角色 soul vs 使用者自訂）

**改進方向**：
```python
class SystemPromptLayers:
    identity: str        # 誰是誰（來自 soul/character）
    behavior_rules: str  # 行為邊界（內建，不應被覆寫）
    tool_constraints: str # 工具使用規則（高風險工具說明）
    output_discipline: str # 輸出格式（情緒標籤、長度限制）
    user_custom: str     # 使用者或插件注入的額外指令

# 組裝時有明確優先級
final = "\n\n".join(filter(None, [
    layers.identity,
    layers.behavior_rules,
    layers.tool_constraints,
    layers.output_discipline,
    layers.user_custom,
]))
```

---

### 6. 訊息模型應用層（A.1 message model）

- [x] 已實作：`MemoryHook.post()` 改為儲存 `ctx.session.history[-max_history:]`，保留完整 tool_calls / ToolMessage


### 7. 中斷處理與 transcript 一致性（A.1 / A.10.1）

- [x] 已實作：`_dispatch` 捕捉 `asyncio.CancelledError`，寫入 `〔已中斷〕` placeholder 後 re-raise
- [ ] 未實作：in-flight request id 追蹤、重連時主動通知使用者

**現狀**：若 WebSocket 在 agent 執行中途斷線，`_dispatch` 沒有感知能力。使用者訊息已寫入 DB，但回應還沒寫入，下次連線重載歷史時會出現懸空的使用者訊息。

**改進方向**：
- `_dispatch` 加入 `asyncio.CancelledError` 處理，捕捉後寫入一條 placeholder assistant 訊息（如 `[中斷]`）以保持 transcript 閉環
- 或在 session 層記錄「in-flight request id」，重連時偵測到未完成請求則主動通知使用者

---



- [ ] 安全模式，啟動一個僅需shuvi依賴的agent，來修復系統
- [x] lipsync  過於陽村
- [x] 本地mcp, skills, soul, 對話md儲存位置, windows: C:\Users\username\.waifu\, macOS: ~/.config/waifu
- [x] 重新思考關於discord, telegram 對話方式的設計...
Session Model in Discord  Discord 中的會話模型
By default:  預設情況下：

each DM gets its own session
每個 DM 都有自己的會話。
each server thread gets its own session namespace
每個伺服器執行緒都有自己的會話命名空間
each user in a shared channel gets their own session inside that channel
共享頻道中的每個使用者都會在該頻道內獲得自己的會話。
So if Alice and Bob both talk to Hermes in #research, Hermes treats those as separate conversations by default even though they are using the same visible Discord channel.
因此，如果 Alice 和 Bob 都在 #research 中與 Hermes 對話，即使他們使用的是同一個可見的 Discord 頻道，Hermes 預設也會將這些對話視為單獨的對話。

This is controlled by config.yaml:
這是由 config.yaml 控制的：

group_sessions_per_user: true

Set it to false only if you explicitly want one shared conversation for the entire room:
只有當您明確希望整個房間共享一個對話時，才將其設定為 false ：

group_sessions_per_user: false

Shared sessions can be useful for a collaborative room, but they also mean:
共享會話對於協作空間很有用，但同時也意味著：

users share context growth and token costs
用戶共享上下文增長和代幣成本
one person's long tool-heavy task can bloat everyone else's context
一個人耗時費力、需要大量工具才能完成的任務，可能會讓其他人的工作內容變得臃腫不堪。
one person's in-flight run can interrupt another person's follow-up in the same room
一個人在飛行途中的奔跑可能會打斷另一個人在同一房間內的後續行動。

- [ ] 進階思考
先定义高风险动作和最小权限模型
再定义主循环或线程生命周期
再定义上下文治理与恢复路径
再定义技能、本地规则与 hook
最后再扩多代理、平台化和复杂生态

- [x] Live2D 前端
- [x] Live2D 情緒需要接收live2d回傳的參數列表
- [x] `waifu/cli/skill.py` — skills registry 整合（skills.sh / GitHub）
- [ ] `waifu/cli/mcp.py` — MCP registry install/uninstall/search
- [ ] 測試補全(還無法處理)

- [x] 讓前端可以透過api設定後端
- [ ] 完整處理後端資料庫
- [x] 有没有预算概念
有没有恢复概念（AgentRunner retry + _dispatch try/except fallback）
有没有上下文膨胀后的自救机制（ContextBuilder token budget 估算裁切）
有没有在工具调用失败后继续推进任务的能力
- [x]工具調用失敗沒有很明確的指示 例如bash command，需要修改hai
- [ ]模型会犯错
工具会扩大错误后果
上下文会膨胀
状态会污染下一轮
用户会打断你
失败会反复出现
- [x]Claude Code 在这里的态度很直接。在 src/query.ts:203 到 :217，系统把 query loop 的可变状态定义得很清楚：

messages
toolUseContext
autoCompactTracking
maxOutputTokensRecoveryCount
hasAttemptedReactiveCompact
pendingToolUseSummary
stopHookActive
turnCount
transition
到了 src/query.ts:268，这些状态在每次 query loop 启动时被整体装配成一个 State 对象，并在后续各个 continue 分支里整体更新。
- [x]
现在来看第二个设计差异：消息模型。

nanobot 的做法：直接用 LLM 的消息格式
# nanobot：消息就是 OpenAI 格式
messages = [
    {"role": "system", "content": "You are a helpful assistant..."},
    {"role": "user", "content": "帮我写个排序函数"},
    {"role": "assistant", "content": "好的...", "tool_calls": [...]},
    {"role": "tool", "tool_call_id": "xxx", "content": "函数已写入 sort.py"},
]
简单直接，消息列表就是给 LLM 看的。

pi-mono 的做法：引入”应用消息”层
// pi-mono：LLM 只认三种消息
type Message = UserMessage | AssistantMessage | ToolResultMessage;

// 但应用层可以有更多消息类型
type AgentMessage = Message | CustomAgentMessages[keyof CustomAgentMessages];

// 宿主应用通过 TypeScript declaration merging 扩展
declare module "@mariozechner/pi-agent-core" {
    interface CustomAgentMessages {
        "user-with-attachments": UserMessageWithAttachments;  // 带附件的用户消息
        artifact: ArtifactMessage;                             // Artifact 操作记录
    }
}
每次调用 LLM 前，经过两步转换：

// 第一步：transformContext（AgentMessage[] → AgentMessage[]）
// 在应用消息层面操作：裁剪旧消息、注入外部知识
let messages = context.messages;
if (config.transformContext) {
    messages = await config.transformContext(messages, signal);
}

// 第二步：convertToLlm（AgentMessage[] → Message[]）
// 过滤自定义类型，转换为 LLM 格式
const llmMessages = await config.convertToLlm(messages);
为什么要多这一层？
用一个具体例子说明。pi-mono 的 web-ui 包实现了一个 Artifact 系统——LLM 可以通过工具调用创建 HTML、SVG、Markdown 等文件，实时渲染在 UI 侧面板中。

当 LLM 创建一个 Artifact 时，消息历史中实际产生了这些记录：

1. [assistant]   toolCall: { name: "artifacts", args: { command: "create",
                    filename: "index.html", content: "<html>..." } }
   → LLM 发出的工具调用请求

2. [toolResult]  "Created file index.html"
   → 工具执行结果

3. [artifact]    { role: "artifact", action: "create", filename: "index.html",
                   content: "<html>..." }
   → 额外的 UI 专用记录
LLM 只需要看第 1、2 条——它通过自己的 toolCall 和 toolResult 已经完全知道发生了什么。

第 3 条 ArtifactMessage 是给 UI 做会话恢复用的。当用户刷新页面，UI 需要从消息历史重建侧面板的 Artifact 状态。如果只有 toolCall + toolResult，就需要反查 assistant 消息的 toolCall.arguments 才能拿到文件内容——而 ArtifactMessage 把内容直接存好了，一条记录就够。

在 convertToLlm 中，这类 UI 专用消息被过滤掉：
- [ ] 換掉peewee，改用更現代的orm（tortoise orm, sqlmodel）
- [x] 檢查對話是否有紀錄adapter資訊，不要使用id來儲存
- [x] 實作logging，使用rich

- [ ] 角色測試 (在此之前需要完成模組化prompt)
- [x] 對，是依序逐句生成，不是並行的。

service.py:78-91 是個普通 for 迴圈：


for sentence in sentences:
    tts_text = _EMOTION_TAG.sub("", sentence).strip()
    audio_bytes = await self._tts.synthesize(tts_text)  # 等這句合成完
    ...
    yield SynthesisResult(...)                           # 才 yield 下一句
每句都要等 TTS API 回來才繼續下一句，是完全串行的。如果回應有 5 句，就要等 5 次 TTS 請求依序完成。

- [ ] 解決滑鼠穿透與各種應用程式覆蓋的問題

- [ ] 模型驅動的動作(吳想法)

- [ ] 實現低延遲的語音管線，需整合語音活動檢測，語音識別，語音合成，並降低整體延遲到可正常對話的範圍內



- [x] MCP
- [x] SKILL

- [x] 現在[emotion:xxxx] 會儲存在訊息裡面 需要解決

- [ ] hai擴充可用ai端點

- [ ] 更像桌面寵物
- [x] 具有能就自主走動的能力(可能需要特化的live2d)
- [x] 用戶離開檢測(前端回傳)
- [x] 新增心跳功能
- [x] 尚未接入cron功能
- [ ] 添加更多tool
- [x] history tree 視覺化(非本專案)
- [ ] 重度更新!!對話與操作ai是是分開的，對話不進行重度程使碼的編寫，只進行專案的規劃，更多在於與使用者對話，輕度助理工作，並總結需求給worker ai
- [x] 添加工具用ai，和agent為分開的處理，例如agent使用claude, 工具用ai可以使用gpt，用來生成對話標題等單一工作
- [x] 統一的用戶訊息build，例如可以呼叫imagemsg("url"), filemsg(data), 來build



累了 完成以下進度就收工
- [x] cli init 要可以選擇供應商，並自動設定對應供應商的url與token
- [x] 移除cli tui
- [?] 接上history tree
- [x] 測試角色prompt ，思考更換角色卡或者soul.md後history tree self那邊該如何處理
- [?] 環境感知，使AI能夠識別螢幕與視窗內容，並可擴充其餘的資訊獲取方式，目前tool尚未有能力可以完成此任務
- [x] 需要新增設定 可以啟用並載入gateway 新增gateway config.yaml，並擴充api與系統接口部分
- [ ] Discord, telegram 測試
- [x] discord, telegram 接上command
- [x] 美化前端對話介面
- [x] 完善cli init指令
- [x] 新增cli config 指令
- [x] 前端完善設定頁面


展示前須處理
- [x] 推最新版hai, shuvi, 將本地套件轉換成線上
- [ ] 能包docker包docker，測試不同網路環境是否可正常運作
- [x] waifu build成cli, 可使用pip install,uv tool 成為cli tool
- [x] 編寫install script(windows, linux, macos)
- [ ] 推送到choco, winget, brew等
- [x] waifu node 自動build
- [...] 編寫技術文檔

- [x] 八千代 語音
- [ ] 前端可更換與上傳角色


以下為無法達成
- [ ] 編寫vrchat plugin
- [ ] 支援多provider
- [ ] 前端對話介面中的模型選擇與工具選擇讓他可以動起來