# Skill 實作 TODO

對齊 [feature.md](feature.md) 中「本地 mcp, skills, soul, 對話 md 儲存位置」與「SKILL」未完成項。
觸發模型：**Progressive disclosure**（system prompt 只注入 name+description；模型呼叫 `skill` tool 才載入 body）。

## 目錄與資料結構

```
<AppPaths.skills_dir>/                  # 已有：~/.waifu/skills (Linux), %USERPROFILE%/Documents/waifu/skills (Win)
├── <skill-name>/
│   ├── SKILL.md                        # frontmatter + body
│   ├── installed.json                  # source / commit / installed_at
│   └── (scripts/ assets/ ...)
```

`SKILL.md` frontmatter:
```yaml
---
name: skill-name
description: 一句話描述什麼時候用這個 skill
allowed-tools: [read, write]            # v1：只解析、不強制
---
（body：任意 markdown，會在模型呼叫 skill tool 時被注入）
```

## 模組規劃（新檔）

| 路徑 | 職責 |
| --- | --- |
| `waifu/skill/__init__.py` | 匯出 `Skill`, `SkillRegistry`, `SkillManifest` |
| `waifu/skill/manifest.py` | `SkillManifest` dataclass + `parse_skill_md(path)` |
| `waifu/skill/loader.py` | 掃描 `skills_dir`、parse manifest、build registry |
| `waifu/skill/registry.py` | `SkillRegistry`：`list()`/`get(name)`/`add()`/`remove()` |
| `waifu/skill/tool.py` | 內建 `skill` tool（progressive disclosure 觸發點） |
| `waifu/skill/installer.py` | `install_local(path)` / `install_github(spec)` / `uninstall(name)` |
| `waifu/skill/hook.py` | `SkillPromptHook`：system prompt 注入可用 skill 清單 |

**注意**：skill 是系統層設施，不走 plugin 系統。由 `Waifu.__init__` 直接把 `skill` tool 加進 `_plugin_registry`、把 `SkillPromptHook` 加進 `_hook_registry`，跟內建 read/write/shell tool 與 MemoryHook/EmotionHook 同層級。

## 工作項目

- [x] `localdocs/skilltodo.md`（本文件）
- [ ] **manifest parser**（`waifu/skill/manifest.py`）
  - 讀 SKILL.md，分離 YAML frontmatter 與 body
  - 沒有 PyYAML 就用最小手寫 parser（避免新增依賴）
  - 驗證 `name` / `description` 必填，`allowed-tools` optional list
- [ ] **SkillRegistry**（`waifu/skill/registry.py`）
  - 持有 `{name: SkillManifest}` in-memory map
  - `list_descriptions()` → 給 system prompt 用的 `(name, description)` list
  - `get_body(name)` → 給 skill tool 用
- [ ] **loader**（`waifu/skill/loader.py`）
  - `scan(skills_dir) -> List[SkillManifest]`，壞掉的 skill log warning 跳過
- [ ] **skill 內建 tool**（`waifu/skill/tool.py`）
  - `Tool(name="skill", parameters={name: str})`
  - func 回傳對應 SKILL.md body；找不到回 error string
  - 透過 closure 注入 registry（無全域變數）
- [ ] **SkillPromptHook**（`waifu/skill/hook.py`）
  - `system_prompt_fragment(ctx)` 回傳所有可用 skill 的清單
  - 由 `Waifu.__init__` 直接 `_hook_registry.register(...)`，不透過 PluginManager
- [ ] **installer**（`waifu/skill/installer.py`）
  - `install_local(src: Path, skills_dir: Path)`：copytree → `<skills_dir>/<skill-name>/`，寫 `installed.json`
  - `install_github(spec: str, skills_dir: Path)`：spec 形如 `user/repo` 或 `user/repo@ref` 或完整 URL；下載 tarball、解壓、找 SKILL.md
  - `uninstall(name, skills_dir)`：rmtree + 防呆（不能跳出 skills_dir）
  - 不引入新依賴；GitHub 用 `urllib` + `tarfile`
- [ ] **CLI 串接**（[waifu/cli/skill.py](../waifu/cli/skill.py)）
  - `skill list` → loader.scan + print
  - `skill install <source>` → 判斷 local/github → installer
  - `skill uninstall <name>` → installer.uninstall
  - `skill search` / `skill update` → 留 TODO（v2 接 skills.sh）
- [ ] **Waifu 啟動整合**（[waifu/waifu.py](../waifu/waifu.py)）
  - `__init__` 建立 `SkillRegistry` + scan
  - 直接 `_plugin_registry.add_tool(make_skill_tool(reg))` + `_hook_registry.register(SkillPromptHook(reg))`
  - 開放 `waifu.skill_registry` property 給 CLI / service 用

## 範圍外（v2 再做）

- skills.sh registry 整合（search/update）
- allowed-tools runtime 強制（沙箱 AgentRunner 工具集）
- skill 版本管理 / 自動更新
- skill 間相依
