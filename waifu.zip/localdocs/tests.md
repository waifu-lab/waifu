# Waifu 測試文件

## 概覽

測試位於 `test/` 目錄，以 **三層 tier** 區分，透過 pytest mark 執行：

```bash
pytest -m unit          # 純邏輯，無 I/O，最快
pytest -m offline       # 整合但不需要 LLM（使用 mock/fake）
pytest -m online        # 需要真實 LLM API（缺 config.toml 自動 skip）
pytest -m "unit or offline"   # CI 常用組合
```

Discord/Telegram 的線上測試另需環境變數：
```bash
DISCORD_BOT_TOKEN=xxx pytest -m online test/test_gateway.py
TELEGRAM_BOT_TOKEN=xxx pytest -m online test/test_gateway.py
```

---

## 測試分層說明

| Tier | Mark | 需要什麼 | 用途 |
|------|------|---------|------|
| Unit | `@pytest.mark.unit` | 無（只需 Python） | 純邏輯、解析、資料結構 |
| Offline | `@pytest.mark.offline` | `Waifu` 實例（需 config.toml） | 整合邏輯，不打 LLM API |
| Online | `@pytest.mark.online` | `config.toml` + LLM API key | Agent 端對端行為驗證 |

### 共用 fixtures（`test/conftest.py`）

| fixture | scope | 說明 |
|---------|-------|------|
| `waifu_config` | module | 從 config.toml 載入 WaifuConfig，缺檔案則 skip |
| `waifu` | module | 無 gateway 的 headless Waifu 實例，模組內共用 |
| `waifu_started` | module | 有呼叫 `start()`（localmode=True）的 Waifu，含 MCP/plugin/cron 恢復 |
| `tmp_dir` | function | 跨平台 temp 目錄（用 `tempfile.TemporaryDirectory`，避免 Windows WinError 5） |

---

## 測試檔案明細

### `test/test_flow.py`（待刪除）

原始整合測試檔，標注「之後刪除」，已被新架構取代。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_plain_qa` | online | 基本問答，驗證 agent 回傳非空且包含正確答案 |
| `test_tool_read` | online | Agent 呼叫 read tool 讀取指定檔案 |
| `test_tool_write` | online | Agent 呼叫 write tool 寫入檔案並驗證檔案存在 |
| `test_tool_shell` | online | Agent 呼叫 shell tool 執行 echo 指令 |

---

### `test/test_skills.py` — Skill 系統

測試 skill 的解析、registry 管理、tool 函式呼叫，以及 agent 載入並遵循 skill 內容。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_parse_skill_md_basic` | unit | 解析含 frontmatter + allowed-tools 的 .md 檔 |
| `test_parse_skill_md_no_allowed_tools` | unit | 空 allowed-tools 清單解析正確 |
| `test_parse_skill_md_missing_name` | unit | 缺 name 欄位時拋出 SkillParseError |
| `test_parse_skill_md_missing_frontmatter` | unit | 無 frontmatter 分隔符時拋出 SkillParseError |
| `test_registry_add_get_list` | unit | SkillRegistry add/get/list 基本操作 |
| `test_registry_get_missing` | unit | 查詢不存在的 skill 回傳 None |
| `test_registry_dedup_by_name` | unit | 同名 skill 後加的覆蓋先加的 |
| `test_skill_tool_returns_body` | unit | make_skill_tool 呼叫後回傳 skill body |
| `test_skill_tool_unknown_returns_error` | unit | 查詢不存在名稱時回傳 error 字串並列出可用項 |
| `test_skill_tool_lists_available` | unit | error 訊息包含已存在的 skill 名稱 |
| `test_skill_registry_in_waifu` | offline | 手動 add 的 skill 在 waifu.skill_registry 中可查到 |
| `test_skill_tool_registered_in_plugin_registry` | offline | `skill` tool 在 plugin_registry 中已存在（__init__ 時自動注冊） |
| `test_agent_loads_and_follows_skill` | online | Agent 呼叫 skill tool、讀取 body、在回覆中輸出指定 marker |

---

### `test/test_mcp.py` — MCP 整合

使用 `FakeMCPAdapter`（in-process）測試 MCPManager 的 add/remove/list 以及 agent 呼叫 MCP tool。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_mcp_manager_add_registers_tools` | unit | add 後 adapter 連線、tools 出現在 plugin_registry |
| `test_mcp_manager_remove_deregisters_tools` | unit | remove 後 adapter 斷線、tools 從 plugin_registry 移除 |
| `test_mcp_manager_duplicate_name_raises` | unit | 同名再 add 拋出 ValueError |
| `test_mcp_manager_remove_nonexistent_noop` | unit | remove 不存在的名稱不拋例外 |
| `test_mcp_tool_callable_directly` | offline | 不經 LLM 直接呼叫 MCP tool func，驗證回傳值 |
| `test_agent_calls_mcp_tool` | online | Agent 發現 mcp_echo tool 並用正確參數呼叫，回傳 echo 結果 |

**FakeMCPAdapter** 提供一個 `mcp_echo` tool，`func(message) → "[mcp_echo] {message}"`，不需要真實子進程。

---

### `test/test_multi_tool.py` — 多工具串接

驗證 AgentRunner loop 能正確處理需要多輪 tool call 的請求。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_read_write_tools_available` | unit | read / write / shell 三個 tool 都在 plugin_registry |
| `test_write_then_read_directly` | unit | 直接呼叫 write_tool 再呼叫 read_tool，不經 LLM |
| `test_write_then_read_chain` | online | Agent 先 write 再 read（需 2 次 tool call） |
| `test_shell_then_read_chain` | online | Agent 用 shell 建立檔案再 read（需 2 次 tool call） |
| `test_three_tool_chain` | online | Agent 串接 write → read → shell（需 3 次 tool call） |
| `test_file_search_chain` | online | Agent 用 file_search 找到剛寫的檔案再 read |

---

### `test/test_cron.py` — Cron 系統

測試 CronExecutor 的 shell/llm 兩種執行模式、cron tool CRUD 操作，以及 agent 透過 tool 管理排程。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_executor_shell_echo` | unit | shell mode：執行 echo 指令，驗證輸出 |
| `test_executor_shell_nonzero_raises` | unit | shell mode：exit 1 時拋出 RuntimeError |
| `test_executor_llm_dispatches_request` | unit | llm mode：dispatch_fn 被呼叫，content = job.command |
| `test_executor_llm_uses_target_conversation` | unit | llm mode：conversation_id / user_id 從 job 欄位取得 |
| `test_cron_tool_create_and_list` | offline | cron tool create 後 list 能看到新工作 |
| `test_cron_tool_delete` | offline | cron tool delete 後 list 不再包含該工作 |
| `test_cron_tool_enable_disable` | offline | cron tool enable/disable 回傳 [ok] |
| `test_cron_tool_invalid_action` | offline | 非法 action 回傳 error 字串 |
| `test_agent_creates_cron_job` | online | Agent 用 cron tool 建立排程工作並確認已建立 |
| `test_agent_lists_cron_jobs` | online | Agent 呼叫 cron list 並回報結果 |

**注意**：CronJob 實例以 in-memory 方式建立（peewee model 不 save），不需要 DB 連線即可測試 CronExecutor。

---

### `test/test_gateway.py` — Discord / Telegram Adapter

測試 adapter 的工廠方法、config 解析、conversation ID 生成，以及無真實 bot 的 mount 操作。

#### Discord

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_discord_default_gateway_config` | unit | default_gateway_config 包含必要欄位且 enabled=False |
| `test_discord_from_gateway_config_disabled` | unit | enabled=False 回傳 None |
| `test_discord_from_gateway_config_no_token` | unit | 空 token 回傳 None |
| `test_discord_from_gateway_config_valid` | unit | 有效設定回傳 DiscordAdapter 實例 |
| `test_discord_build_gateway_status` | unit | 含 name / enabled / configured 欄位 |
| `test_discord_group_conversation_id_per_user` | unit | group_sessions_per_user=True 時 ID 包含 user_id |
| `test_discord_group_conversation_id_shared` | unit | group_sessions_per_user=False 時 ID 只含 channel_id |
| `test_discord_adapter_mountable` | offline | 可 mount 到 Waifu（不 start） |
| `test_discord_dm_request_shape` | offline | 模擬 DM on_message，驗證 IncomingRequest 欄位 |
| `test_discord_group_request_shape` | offline | GROUP mode conversation ID 格式正確 |
| `test_discord_adapter_start_stop` | online | 需 `DISCORD_BOT_TOKEN` env var，mount 不 crash |

#### Telegram

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_telegram_default_gateway_config` | unit | 包含 trigger_command 欄位 |
| `test_telegram_from_gateway_config_disabled` | unit | disabled 回傳 None |
| `test_telegram_from_gateway_config_no_token` | unit | 空 token 回傳 None |
| `test_telegram_from_gateway_config_valid` | unit | 有效設定回傳 TelegramAdapter 實例 |
| `test_telegram_build_gateway_status` | unit | 狀態結構正確 |
| `test_telegram_adapter_mountable` | offline | 可 mount 到 Waifu（不 start） |
| `test_telegram_adapter_start_stop` | online | 需 `TELEGRAM_BOT_TOKEN` env var |

---

### `test/test_self_maintenance.py` — Agent 自我維護

測試 AppConfigService 的 hot-reload 能力，以及 agent 透過 shell tool 呼叫 CLI 讀寫設定。

| 測試名稱 | Tier | 說明 |
|---------|------|------|
| `test_config_service_set_and_get` | unit | set 後 get 回傳新值 |
| `test_config_service_hot_reload_context` | unit | 設定 context.max_history_messages 立即反映在 ContextBuilder |
| `test_config_service_hot_reload_provider_temperature` | unit | 設定 provider.temperature 立即反映在 AgentRunner.provider |
| `test_config_service_gateway_key_returns_note` | unit | gateway 類 key 不 hot-reload，回傳 "requires restart" note |
| `test_config_service_get_all` | unit | get_all 回傳含 "provider.model" 的非空 dict |
| `test_config_repo_set_persists` | offline | AppConfigRepository set 後 get 同一 session 可讀到 |
| `test_config_service_replace_from_get_all` | offline | get_all 的前 5 個 key 可逐一 get 並對應 |
| `test_agent_reads_config_via_cli` | online | Agent 用 shell tool 呼叫 `waifu config list`，回傳非空 |
| `test_agent_updates_temperature_via_cli` | online | Agent 用 shell tool set + get，回覆包含 "0.55" |
| `test_agent_self_reports_model` | online | Agent 用 shell tool 取得目前使用的 model 名稱 |

---

### `test/test_cli.py` — CLI

測試 CLI 指令路由邏輯（in-process）與 subprocess 執行（需 `waifu` 安裝於 PATH）。

#### Unit（in-process，patch sys.argv）

| 測試名稱 | 說明 |
|---------|------|
| `test_cli_main_no_args_prints_help` | 無參數呼叫 main()，stdout 含 "waifu" |
| `test_cli_config_routes_to_list` | `cmd_config(["list"])` 路由到 `_cmd_list` |
| `test_cli_config_get_requires_path` | `cmd_config(["get"])` 缺路徑時 SystemExit |
| `test_cli_config_set_requires_two_args` | `cmd_config(["set", "x"])` 缺 value 時 SystemExit |
| `test_cli_unknown_command_exits` | 未知指令 SystemExit |

#### Offline（subprocess，不需 server）

| 測試名稱 | 說明 |
|---------|------|
| `test_cli_subprocess_help` | `waifu` 無參數，exit 0，stdout 含 "waifu" |
| `test_cli_version` | `waifu version`，exit 0，輸出非空 |
| `test_cli_config_list_offline` | `waifu config list`，exit 0 |
| `test_cli_config_get_provider_model` | `waifu config get provider.model`，exit 0 |
| `test_cli_skill_list` | `waifu skill list`，exit 0 |
| `test_cli_mcp_list` | `waifu mcp list`，exit 0 |
| `test_cli_cron_list` | `waifu cron list`，exit 0 |
| `test_cli_conversations_list` | `waifu conversations`，exit 0 |
| `test_cli_character_list` | `waifu character list`，exit 0 |

#### Online（需 server 運行中）

| 測試名稱 | 說明 |
|---------|------|
| `test_cli_config_set_online` | `waifu config set` 透過 API 更新，stdout 含新值 |
| `test_cli_cron_add_and_remove` | `waifu cron add` + `waifu cron remove` round-trip |

---

## 測試數量統計

| 檔案 | Unit | Offline | Online | 合計 |
|------|:----:|:-------:|:------:|:----:|
| test_flow.py（待刪） | 0 | 0 | 4 | 4 |
| test_skills.py | 10 | 2 | 1 | 13 |
| test_mcp.py | 4 | 1 | 1 | 6 |
| test_multi_tool.py | 2 | 0 | 4 | 6 |
| test_cron.py | 4 | 4 | 2 | 10 |
| test_gateway.py | 11 | 4 | 2 | 17 |
| test_self_maintenance.py | 5 | 2 | 3 | 10 |
| test_cli.py | 5 | 9 | 2 | 16 |
| **合計** | **41** | **22** | **19** | **82** |

> `pytest -m unit` 與 `pytest -m offline` 共 **63 個**測試可在無 LLM 的環境下驗證。

---

## 注意事項

### Windows tmp_path 問題
`pytest-asyncio` 在 `asyncio_mode=auto` 下會包裝所有 fixtures，導致 Windows 上的 `tmp_path` 出現 WinError 5（Access Denied）。所有需要暫存目錄的測試改用 `conftest.py` 提供的 `tmp_dir` fixture（基於 `tempfile.TemporaryDirectory`）。

### Peewee 全域 proxy
`Database._db` 是 module-level singleton。多個 `Waifu` 實例若在同一 pytest session 中建立，會以最後一次 `init()` 的路徑為準。目前所有 waifu fixtures 都使用 `AppPaths.resolve()` 指向同一實際資料庫，不存在衝突。

### test_flow.py
標注「之後刪除」，保留以作為基準回歸測試，確認基礎 read/write/shell tool 行為正確。
