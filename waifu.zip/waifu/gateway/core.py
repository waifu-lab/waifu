import asyncio
import inspect
from typing import Any, Awaitable, Callable, Dict, List, Optional

from waifu.logger import logger
from waifu_types import BaseGatewayAdapter, IncomingRequest, OutgoingResponse

from .lane import LaneManager
from .session import SessionManager


class GatewayCore:
    def __init__(self, session_ttl: int = 3600, lane_max_queue: int = 10):
        self._adapters: List[BaseGatewayAdapter] = []
        self._session_manager = SessionManager(ttl=session_ttl)
        self._lane_manager = LaneManager(max_queue_size=lane_max_queue)
        self._dispatch_handler: Optional[Callable[[IncomingRequest], Awaitable[OutgoingResponse]]] = None
        self._command_service: Any = None
        self._started: bool = False
        self.capabilities: Dict[str, Any] = {}

    def mount(self, adapter: BaseGatewayAdapter) -> "GatewayCore":
        self._adapters.append(adapter)
        return self

    async def mount_adapter(self, adapter: BaseGatewayAdapter) -> None:
        self._adapters.append(adapter)
        if self._started:
            await adapter.start(self)

    def set_dispatch_handler(
        self,
        handler: Callable[[IncomingRequest], Awaitable[OutgoingResponse]],
    ) -> None:
        """注入請求處理器（由 Waifu 在組裝時呼叫）"""
        self._dispatch_handler = handler

    def set_command_service(self, service: Any) -> None:
        """注入平台內建指令服務，供 adapters 註冊 native commands。"""
        self._command_service = service

    @property
    def command_service(self) -> Any:
        return self._command_service

    async def dispatch(self, request: IncomingRequest) -> None:
        """將請求放入對應 conversation 的 Lane，確保串行執行"""
        lane = self._lane_manager.get_or_create(request.conversation_id)
        await lane.enqueue(request, self._handle_request)

    async def start(self) -> None:
        """啟動所有掛載的 Adapter"""
        self._started = True
        await asyncio.gather(*[adapter.start(self) for adapter in self._adapters])

    async def stop(self) -> None:
        self._started = False
        for adapter in self._adapters:
            stop_fn = getattr(adapter, "stop", None)
            if callable(stop_fn):
                try:
                    result = stop_fn()
                    if inspect.isawaitable(result):
                        await result
                except Exception:
                    logger.exception("GatewayCore: error stopping adapter {}", getattr(adapter, "name", adapter))

    @property
    def session_manager(self) -> SessionManager:
        return self._session_manager

    @property
    def adapters(self) -> List[BaseGatewayAdapter]:
        return list(self._adapters)

    async def _handle_request(self, request: IncomingRequest) -> None:
        if self._dispatch_handler is None:
            logger.warning("GatewayCore: no dispatch_handler set, dropping request {}", request.request_id)
            return
        try:
            response = await self._dispatch_handler(request)
            await request.reply_fn(response)
        except Exception:
            logger.exception("GatewayCore: error handling request {}", request.request_id)
